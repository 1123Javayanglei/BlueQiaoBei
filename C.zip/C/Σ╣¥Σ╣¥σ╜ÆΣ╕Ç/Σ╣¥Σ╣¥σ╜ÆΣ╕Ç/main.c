//
//  main.c
//  九九归一
//
//  Created by 杨磊 on 2019/5/18.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//
//int main()
//{
//    int i,j;  //i控制行数,j控制列数
//    printf("九九归一:\n");
//    for (i=1; i<=9; i++) {
//        for (j=1; j<=i; j++) {
//            printf("%d*%d=%d ",i,j,i*j);
//        }
//         printf("\n");
//    }
//    return 0;
//}


#include <stdio.h>

int main()
{
    printf("九九乘法表\n");
    int i,j;    //  i行,j列
    for (i=1; i<=9; i++) {
        for (j=1; j<=i; j++) {
            printf("%d*%d=%d ",i,j,i*j);
        }
         printf("\n");
    }
   
    return 0;
}
