//
//  main.c
//  整数的分解
//
//  Created by 杨磊 on 2019/5/16.
//  Copyright © 2019 Yang. All rights reserved.
//
/*
#include <stdio.h>

int main()
{
    int x;
    scanf("%d",&x);
    int digit;
    int t=0;
    
    while (x>0) {
        digit=x %10;
        printf("%d",digit); //  e.g. 007 700
        t=t*10+digit;
        //printf("x=%d,digit=%d,t=%d\n",x,digit,t);
        x/=10;
    }
    
   // printf("%d\n",t);
    return 0;
}
*/
