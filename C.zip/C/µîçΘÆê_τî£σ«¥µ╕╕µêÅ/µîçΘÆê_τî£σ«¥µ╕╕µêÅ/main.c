#include <stdio.h>
int main()
{
    int a=0;
    int *p=&a;
    printf("%d\n",a);
    return 0;
}
