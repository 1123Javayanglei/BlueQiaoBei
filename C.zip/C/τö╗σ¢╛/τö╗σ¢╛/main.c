//
//  main.c
//  画图
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a,b,c;
    printf("Please enter there\n");
    scanf("%d %d %d",&a,&b,&c);
    if (a>b) {
        if (b>c) {
            printf("min:%d\n",c);
        }else{
            printf("min:%d\n",b);
        }
    }else{
        if (a>c) {
            printf("min:%d\n",c);
        }else{
            printf("min:%d\n",a);
        }
    }
    return 0;
}
    

