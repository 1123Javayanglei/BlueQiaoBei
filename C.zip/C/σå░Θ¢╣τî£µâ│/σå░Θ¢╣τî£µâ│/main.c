//
//  main.c
//  冰雹猜想
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

//
//  main.c
//  水仙花数
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a;
    int c=1;
    scanf("%d",&a);
    //printf("%d\n",11 % 2);
    do {
        if (a % 2) {    //奇数对2取余数等于 1,偶数对2取余数等于0
            a =a*3+1;
            printf("(%d):%d\n",c++,a);
        } else {
            a/=2;
            printf("(%d):%d\n",c++,a);
        }
    } while (a!=1);
    return 0;
}

