//
//  main.c
//  独身数
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int num;
    int a;
    printf("独身数:\n");
    for (num=0; num<=9; num++) {
        a=num;
        if (num==(a)) {
            printf("%d\n",num);
        }
    }
    return 0;
}
