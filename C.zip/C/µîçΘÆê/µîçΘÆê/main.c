//
//  main.c
//  指针
//
//  Created by 杨磊 on 2019/5/21.
//  Copyright © 2019 Yang. All rights reserved.
//


#include <stdio.h>
int main()
{
    int a=10;       //定义一个int型的变量a
    int* p;         //定义一个int*型的指针变量p
    p=&a;           //p 指向 a 所在的存储空间 ,&是取得地址符号,作用是取得a的地址
    
    int* q;
//    q=p;
    q=p;
    
    int b=5;
    int*w =&b;
    
    printf("%d\n",a);
    printf("%d\n",*p); //引用指针变量p,方法 *p.
    printf("%d\n",*q);
    printf("%d\n",*w);
    printf("%x\n",w);




    return 0;
}
