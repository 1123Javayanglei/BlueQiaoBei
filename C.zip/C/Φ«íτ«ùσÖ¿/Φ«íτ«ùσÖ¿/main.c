//
//  main.c
//  计算器
//
//  Created by 杨磊 on 2019/5/23.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

float sum;

void Add(float op1,float op2);
void Sub(float op1,float op2);
void Mult(float op1,float op2);
void Div(float op1,float op2);

int main()
{
    float op1,op2;
    char ch;
    while (1) {
        scanf("%f%c%f",&op1,&ch,&op2);
        switch (ch) {
            case '+':
                Add(op1, op2);
                break;
            case '-':
                Sub(op1, op2);
                break;
            case '*':
                Mult(op1, op2);
                break;
            case '/':
                Div(op1, op2);
                break;
                
            default:
                break;
        }
    }
    return 0;
}

void Add(float op1,float op2)
{
    sum=op1 +op2;
    printf("%0.2f\n",sum);
}
void Sub(float op1,float op2)
{
    sum=op1 - op2;
    printf("%0.2f\n",sum);
}
void Mult(float op1,float op2)
{
    sum= op1 * op2;
    printf("%0.2f\n",sum);
}
void Div(float op1,float op2)
{
    if (op2 == 0) {
        printf("除数不能为0\n");
    }else {
        sum=op1 / op2;
        printf("%0.2f\n",sum);
    }
}
