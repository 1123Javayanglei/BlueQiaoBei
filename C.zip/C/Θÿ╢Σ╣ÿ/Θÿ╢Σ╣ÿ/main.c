
#include <stdio.h>
int main(){
    int i,j=5;
    double sum=1;
    
    for(i=1;i<=j;i++){
        sum*=i;
    }
    printf("%lf\n",sum);
    return 0;
}
