//
//  main.cpp
//  类模版
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;
template <typename T >
class Compare {
private: //私有的
    T t1,t2;
public: //公共的
    Compare (T a,T b) :t1(a),t2(b){}
    T max(){ return t1 >t2 ? t1:t2;}
    T min(){return t1 < t2 ? t1:t2;}
};
int main()
{
    Compare<int> c1(1,2);
    cout << "int max:"<<c1.max() <<endl;
    Compare<double> c2(1.2, 3.4);
    cout <<"duoble min:"<<c2.min() <<endl;
    Compare<char> c3('a','b');
    cout << "char max:"<< c3.max() <<endl;
    return 0;
}
