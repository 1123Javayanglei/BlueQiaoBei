//
//  main.c
//  三只小猪
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a,b,c,t;
    printf("请输入三只小猪的体重,用空格隔开:\n");
    scanf("%d %d %d",&a,&b,&c);
    printf("小猪的体重是:%d %d %d\n",a,b,c); //where into 9 3 6
    if (a>b) {  //if a>b ,交换a b
        t=a;
        a=b;
        b=t;
    }
    if (a>c) { //if a>c ,交换 a c
        t=a;
        a=c;
        c=t;
    }
    if (b>c) { //if b>c ,交换 b c
        t=b;
        b=c;
        c=t;
    }
    printf("从小到大为:%d %d %d\n",a,b,c);
    return 0;
}
