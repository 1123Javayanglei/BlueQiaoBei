//
//  main.c
//  找零计算机
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int p,b;
    printf("Please enter 金额:\n");
    scanf("%d",&p);
    printf("please enter 票面:\n");
    scanf("%d",&b);
    if (b>=p) {
        printf("zhao nin:%d\n",b-p);
    }else{
   printf("Please change QQ\n");
    }
    return 0;
}
