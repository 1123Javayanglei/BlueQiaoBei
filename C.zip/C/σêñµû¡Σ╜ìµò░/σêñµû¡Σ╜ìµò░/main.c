//
//  main.c
//  判断位数
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int x;
    int n=0;
    scanf("%d",&x);
    do{
        n++;
        x/=10;
    }while (x>0) ;
    printf("%d\n",n);
    return 0;
}
