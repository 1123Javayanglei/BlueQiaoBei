//
//  main.c
//  最大值和最小值
//
//  Created by 杨磊 on 2019/5/23.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//
//int main()
//{
//    int a[50];  //定义数组,存放元素
//    int MAX,MIN;
//    int i,n;    //n,储存元素的个数,    i,存储每个元素
//    int j=0;       //最小值的位置
//    int k=0;        //最大值的位置
//    printf("请输入数组元素的个数:\n");
//    scanf("%d",&n);
//    printf("请输入数字\n");
//    for (i=0; i<n; i++) {
//        scanf("%d",&a[i]);
//    }
//    MIN = a[0];
//    for (i=1; i<n; i++) {
//        if (a[i]<MIN) {
//            MIN=a[i];
//            j=i+1;
//        }
//
//    }
//    MAX = a[0];
//    for (i=1; i<n; i++) {
//        if (a[i]>MAX)
//        {
//            MAX=a[i];
//            k=i+1;
//        }
//    }
//    printf("最小值的位置是:%d\n",j);
//    printf("最小值是:%d\n",MIN);
//    printf("最大值的位置是:%d\n",k);
//    printf("最大值是:%d\n",MAX);
//    return 0;
//}

//#include <stdio.h>
//int main()
//{
//    int n;
//    int a[35]={0};
//    for (n=0; n<10; n++) {
//        a[n]=n;             //赋值
//        printf("%d\n",a[n]);    //输出
//
//
//    }
//    printf("\n");
//    int i;
//    for (i=0; i<35; i++) {
//        printf("%d\n",a[i]);        //输出
//    }
//    return 0;
//}

//#include <stdio.h>
//int main()
//{
//    int i;
//    int a[10];
//    for (i=0; i<10; i++) {        //使用for循环为一个数组赋值，并将数组倒叙输出。
//        a[i]=i;
//    }
//    for (i=9; i>=0; i--) {
//         printf("%d ",a[i]);
//    }
//    return 0;
//}

//#include <stdio.h>
//int main(void){
//    int i,a[10];
//    for(i=0;i<10;)            //同上
//        a[i++]=i;
//    for(i=9;i>=0;i--)
//        printf("%d ",a[i]);
//    return 0;
//}

//#include <stdio.h>
//int main()
//{
//    int i,MAX;
//    int a[10];
//    for (i=0; i<10; i++) {        //输入10位整数,求最大值
//        scanf("%d",&a[i]);
//    }
//    MAX=a[0];
//    for (i=0; i<10; i++) {
//
//        if (a[i]>MAX) {
//            MAX=a[i];
//        }
//    }
//    printf("MAX = %d\n",MAX);
//    return 0;
//}

#include <stdio.h>
int main()
{
    int i,n;
    int MIN,MAX;
    int a[1000];
    printf("Please inupt the size of array:\n");
    scanf("%d",&n);
    printf("Please enter %d Number:\n",n);
    for (i=0; i<n; i++) {
        scanf("%d",&a[i]);
     }
    MIN=a[0];
        for (i=0; i<n; i++) {
            if (a[i]<MIN) {
                MIN=a[i];
            }
        }
    MAX=a[0];
        for (i=0; i<n; i++) {
    
            if (a[i]>MAX) {
                MAX=a[i];
            }
        }
    printf("MAX = %d\n",MAX);
    printf("MIN =%d\n",MIN);
    return 0;
}
