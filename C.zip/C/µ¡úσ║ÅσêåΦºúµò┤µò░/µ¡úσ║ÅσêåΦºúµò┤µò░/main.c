//
//  main.c
//  正序分解整数
//
//  Created by 杨磊 on 2019/5/17.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//
//int main()
//{
//    int x;
//
//    scanf("%d",&x);
//    int t=0;
//    do {
//        int d=x%10;
//        t=t*10+d;
//        x/=10;
//    } while (x>0);
//    printf("t=%d\n",t);
//    x=t;
//    do {
//        int d=x%10;
//        printf("%d",d);
//        if (x>9) {
//            printf(" ");
//        }
//        x/=10;
//    } while (x>0);
//    printf("\n");
//    return 0;
//}
/*
 //倒序输出
#include <stdio.h>
int main()
{
    int x;
    
    scanf("%d",&x);
    
    do {
        int d=x%10;
        printf("%d ",d);
        x/=10;
    } while (x>0);
    printf("\n");
    return 0;
}
 */
//#include <stdio.h>
//int main()
//{
//    int x;
//    scanf("%d",&x);
//    int t=0;
//    do {
//        int d=x%10;
//        t=t*10+d;
//        x/=10;
//    } while (x>0);
//    printf("x=%d,t=%d\n",x,t);
//    x=t;
//    do {
//        int d=x%10;
//        printf("%d",d);
//        if (x>9) {
//            printf(" ");
//        }
//        x/=10;
//    } while (x>0);
//    printf("\n");
//    return 0;
//}
#include <stdio.h>
int main()
{
    int x;
    scanf("%d",&x);
   // x=13425;
//    13425/10000 ->1;
//    13425 %10000 ->3425
//    1000 /10     ->1000
//    3425 /1000 ->3;
//    3425 %1000 ->425
//    1000 /10    ->100
//    425 /100 ->25
//    425 %100 -4;
//    100 /10 ->10
//    25 /10 ->2;
//    25 %10 ->5;
//    10 /10 ->1
//    5 /1 ->5
//    5 %1 ->5
//    1 /10 ->0
    int cnt=0;
    int mask=1;
    int t=x;
    while (t>9) {
        t/=10;
        mask *=10;
        cnt++;
    }
    printf("x=%d,mask=%d\n",x,mask);
    do {
        int d =x/mask;
        printf("%d",d);
        if (mask>9) {
            printf(" ");
        }
        x%=mask;
        mask /=10;
//        printf("x=%d,mask=%d,d=%d\n7",x,mask,d);
    }while(mask>0);
    printf("\n");
    return 0;
}
