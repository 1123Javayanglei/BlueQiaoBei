//
//  main.c
//  自增自减少
//
//  Created by 杨磊 on 2019/5/12.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
//    int a;
//    a=10;
//
//    printf("a++=%d\n",a++);
//    printf("a=%d\n",a);
//
//    printf("a++=%d\n",++a);
//    printf("a=%d\n",a);
//
//    printf("%d\n",10 + 9 * ((8 + 7) % 6) + 5 * 4 % 3 * 2 + 3 );
//    printf("%d\n",1 + 2 + (3 + 4) * ((5 * 6 % 7 / 8) - 9) * 10);
//    return 0;

    int a;
    printf("请输入一个整数:\n");
    scanf("%d",&a);
    printf("--num=:%d\n",--a);
    printf("%d\n",(++a)+(a++) *(a--));
    return 0;

}

