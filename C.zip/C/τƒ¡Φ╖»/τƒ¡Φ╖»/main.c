//
//  main.c
//  短路
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>
/*
 
 逻辑运算时自左边向右进行的,如果左边的结果已经能够决定结果了,就不会做右边的运算;
 
 a==6 && b==1;
 
 a==6 && b+=1; //   ❌
 
 对于&&,左边是falsed时,就不做右边了;
 
 对于||,左边是true时,就不做右边了;
 
*/
int main()
{
    int a=-1;
    if (a>0 && a++>1) {          //不要把赋值,包括符合赋值组合进入表达式!
        printf("ok/n");
    }
    printf("%d\n",a);
    return 0;
}
