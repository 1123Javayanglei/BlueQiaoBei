//
//  main.c
//  兔子数列
//
//  Created by 杨磊 on 2019/5/23.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//
//int getNum(int n);
//
//int main()
//{
//    printf("f(1)=%d\n",getNum(1));
//    printf("f(2)=%d\n",getNum(2));
//    printf("f(3)=%d\n",getNum(3));
//    printf("f(4)=%d\n",getNum(4));
//    printf("f(5)=%d\n",getNum(5));
//    printf("f(6)=%d\n",getNum(6));
//    printf("f(7)=%d\n",getNum(7));
//    printf("f(8)=%d\n",getNum(8));
//    printf("f(9)=%d\n",getNum(9));
//    printf("f(10)=%d\n",getNum(10));
//    printf("f(11)=%d\n",getNum(11));
//    printf("f(12)=%d\n",getNum(12));
//    return 0;
//}
//
//int getNum(int n)
//{
//    if (n==1 || n==2)
//    {
//        return 1;
//
//    }
//    return getNum(n-2) + getNum(n-1);
//
//}

#include <stdio.h>

int getNum(int n)
{
    if (n==1 || n==2) {
        return 1;
    }
    return getNum(n-1) + getNum(n-2);
}

int main()
{
        printf("f(1)=%d\n",getNum(1));
        printf("f(2)=%d\n",getNum(2));
        printf("f(3)=%d\n",getNum(3));
        printf("f(4)=%d\n",getNum(4));
        printf("f(5)=%d\n",getNum(5));
        printf("f(6)=%d\n",getNum(6));
        printf("f(7)=%d\n",getNum(7));
        printf("f(8)=%d\n",getNum(8));
        printf("f(9)=%d\n",getNum(9));
        printf("f(10)=%d\n",getNum(10));
        printf("f(11)=%d\n",getNum(11));
        printf("f(12)=%d\n",getNum(12));
        printf("f(20)=%d\n",getNum(20));
    

}
