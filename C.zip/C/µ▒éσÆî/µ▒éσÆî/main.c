//
//  main.c
//  求和
//
//  Created by 杨磊 on 2019/5/17.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//void sum(int begin,int end);    //声明
//
//int main()
//{
//    sum(1,10);      //int sum(int ,int)
//    sum(20,30);
//    sum(35,45);
//    return 0;
//}
//void sum(int begin,int end) // 定义
//{
//    int i;
//    int sum=0;
//    for (i=begin; i<=end; i++) {
//        sum+=i;
//    }
//    printf("%d到%d的和是%d\n",begin,end,sum);
//}

#include <stdio.h>
void cheer(int i)
{
    printf("cheer %d\n",i);
}
int main()
{
    double f=2.0;
    cheer(f); 
    
    return 0;
}
