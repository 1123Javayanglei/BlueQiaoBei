//
//  main.c
//  回文素数
//
//  Created by 杨磊 on 2019/5/20.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int flag;
    int n;
    int i;
    for (n=10; n<1000; n++) {
        for (i=2; i<n; i++) {
            flag=1;
            if (n % i == 0) {
                flag =0;
                break;
            }
        }
        if (flag == 1) {
            if (n /100 == 0) {
                if (n/10 == n%10) {
                    printf("%4d",n);
                }
            }
            else{
                if (n/100 == n %10) {
                    printf("%4d",n);
                }
            }
        }
    }
    return 0;
}
