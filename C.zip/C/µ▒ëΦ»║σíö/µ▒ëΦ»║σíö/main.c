//
//  main.c
//  汉诺塔
//
//  Created by 杨磊 on 2019/5/23.
//  Copyright © 2019 Yang. All rights reserved.
//

//#include <stdio.h>
//
//int getNum(int n)
//{
//    if (n==1) {
//        return 1;
//    }else{
//        return 2*getNum(n-1)+1;
//    }
//    return 0;
//}
//
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    int nun;
//    nun =getNum(n);
//    printf("%d片需要移动%d次\n",n,nun);
//}




//
//#include<stdio.h>
//
//void getnum(int n,char x,char y,char z)
//{
//    int cent=0;
//    if(n == 1)
//    { printf("圆盘编号%d：从%c移动到%c\n",n,x,z);
//    }
//    else
//    {
//        getnum(n-1,x,z,y);
//        printf("圆盘编号%d：从%c移动到%c\n",n,x,z);
//        getnum(n-1,y,x,z);
//        cent++;
//    }
//}
//
//int main()
//{
//    //A、B、C分别代表三个柱子
//    char ch1 = 'A';
//    char ch2 = 'B';
//    char ch3 = 'C';
//
//    //n代表圆盘的个数
//    int n;
//    printf("请输入圆盘个数：");
//    scanf("%d",&n);
//    getnum(n,ch1,ch2,ch3);
//
//    return 0;
//}
//
////将n个圆盘从x柱子借助y柱子移动到z柱子上


#include <stdio.h>

int getNum(int n)
{
    if (n==1) {
        return 1;
    }else{
        return 2*getNum(n-1)+1;
    }
}

int main()
{
    int n;
    printf("请输入盘子的个数:");
    scanf("%d",&n);
    getNum(n);
    printf("%d个盘,移动%d次\n",n,getNum(n));
    
}

