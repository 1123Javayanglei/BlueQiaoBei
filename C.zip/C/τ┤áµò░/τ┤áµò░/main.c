//
//  main.c
//  素数
//
//  Created by 杨磊 on 2019/5/16.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>
int main()
{
    int x;
    for (x=10;x<1000;x++)
    {
        int i;
        int isPrime=1; //x是素数
        for (i=2; i<x; i++) {
            if (x % i ==0) {
                isPrime=0;
                break;
            }
        }
        if (isPrime == 1) //判断是否为素数
        {
            if (i/100 ==0) //判断是否是两位数
            {
                if (i/10 == i % 10) {  //判断十位数和个位数是否相同
                    printf("%4d\n",i);
                }
            }
            else {
                if (i/100 == i %10) { //判断百位数和个位数是否相同
                    printf("%4d\n",i);
                }
            }
        }
    }
    printf("\n");
        return 0;
}
