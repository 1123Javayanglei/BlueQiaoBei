#include <stdio.h>

void maopao(int s[],int n)
{
    int i,j,tmp;
    for (i=0; i<n-1; i++) {
        for (j=0; j<n-1; j++) {
            if (s[j]>s[j+1]) {
                tmp=s[j];
                s[j]=s[j+1];
                s[j+1]=tmp;
            }
        }
    }
}
int main()
{
    
    int i;
    int a[10];

    printf("Please input 10 Number:\n");
    
    for (i=0; i<10; i++) {
        scanf("%d",&a[i]);
    }
    printf("%d \n",&i);
    maopao(a, 10);
    
    printf("After Quick Sort:\n");
    
    for (i=0; i<10; ++i) {
        printf("%d ",a[i]);
    }
    
    printf("\n");
    
    return 0;
}


