//
//  main.c
//  比大小
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
   int a,b;
   printf("请输入两个数:\n");
    scanf("%d %d",&a,&b);
   // printf("%d\n", 5<=4 >1); 关系运算符 5<=4 -->0, 0>1 -->0
//    printf("%d较大\n",(a>b?a:b));
    if (a>b) {
        printf("%d比较大\n",a);
    }else {
        printf("%d比较大\n",b);
    }
    return 0;
}
