//
//  main.c
//  北斗七星数
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int num;
    int a,b,c,d,e,f,g;
    printf("北斗七星数:\n");
    /*
     printf("%d\n",54748 % 10);
     printf("%d\n",54748 /10 %10);
     printf("%d\n",54748 /100 % 10);
     printf("%d\n",54748 /1000 %10);
     printf("%d\n",54748 /10000 );
     */
    
    for (num=1000000; num<=9999999; num++) {
        a=num % 10;
        b=num /10 %10;
        c=num /100 % 10;
        d=num /1000 % 10;
        e=num /10000% 10 ;
        f=num /100000 % 10;
        g=num /1000000;
        if (num==(a*a*a*a*a*a*a+b*b*b*b*b*b*b+c*c*c*c*c*c*c+d*d*d*d*d*d*d+e*e*e*e*e*e*e+f*f*f*f*f*f*f+g*g*g*g*g*g*g)) {
            printf("%d\n",num);
        }
    }
    return 0;
}
