//
//  main.c
//  月亮与六便士
//
//  Created by 杨磊 on 2019/5/16.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int x;
    int a,b,c;
    //int exit=0;
    
    scanf("%d",&x);
    for (a=1; 1< x*10; b++) {
        for (b=2; b< x*10/2; b++) {
            for (c=1; c< x*10/5; c++) {
                if (a+b*2+c*5 == x*10) {
                    printf("可以用%d个1角➕%d个2角➕%d个5角得到%d元\n",a,b,c,x);
                    goto out;
                  //  exit=1;
                  //  break;
                }
            }
          //  if (exit==1) {
          //      break;
           // }
        }
    //if (exit==1) {
    //        break;
     //   }
    }
out:
    return 0;
}

