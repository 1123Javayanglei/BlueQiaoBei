//
//  main.c
//  yuan
//
//  Created by 杨磊 on 2019/6/12.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>
int main()
{
    int a=1;
    int A=2;
    printf("%d\n",A);
    return 0;
}
