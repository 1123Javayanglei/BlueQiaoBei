//
//  main.c
//  水仙花数
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int num,a,b,c;
    printf("水仙花数:\n");
    for (num=100; num<=999; num++)
    {
        a=num %10; //个位数
        b=num /10 %10 ;//十位数
        c=num /100 ; //百位数;
        if (num==(a*a*a+b*b*b+c*c*c))
        {
            printf("%d\n",num);
        }
    }
    printf("\n");
    //printf("%d\n",125 % 10);
    return 0;
}
