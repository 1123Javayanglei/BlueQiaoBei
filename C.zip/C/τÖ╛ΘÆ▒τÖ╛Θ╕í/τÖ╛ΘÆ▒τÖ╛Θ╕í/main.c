//
//  main.c
//  百钱百鸡
//
//  Created by 杨磊 on 2019/5/18.
//  Copyright © 2019 Yang. All rights reserved.
//





//    cock (0,20)
//    hen (0,33)
//    chicken (0,100)
//    cock + hen +chicken =100
//    5*cock +3*hen +chicken/3 =100

//#include <stdio.h>
//
//int main()
//{
//    int cock,hen,chicken;
//    for (cock=0; cock<=20; cock++) {
//        for (hen=0; hen<=33; hen++) {
//            chicken=100-cock-hen;
//            if ((cock*5+hen*3+chicken/3.0) == 100) {
//                printf("🐓:%d,🐔:%d,🐤:%d\n",cock,hen,chicken);
//            }
//        }
//
//    return 0;
//}

#include <stdio.h>
int main()
{
    int a,b,c;
    for (a=0; a<=20; a++) {
      
        for (b=0; b<=33; b++) {
            for (c=0; c<=100; c++) {
                if (((a+b+c)==100)&&((5*a+3*b+c/3.0) == 100)) {
                    printf("🐓%d🐔%d🐤%d\n",a,b,c);
                }
            }
        }
    }
    return 0;
}
