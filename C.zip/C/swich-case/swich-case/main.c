//
//  main.c
//  swich-case
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    
    printf("Please into one number(1~4):\n");
    const int PN=2;
    int a;
    scanf("%d",&a);
    switch (a) {                    // 参数类型必须为int
        case 1:                     //可以为常数,也可以是常数计算的表达式
            printf("hello!\n");
            break;
        case PN:
            printf("goodmorring\n");
            break;  //跳出
        case 3:     //站牌
            printf("goodevening\n");
            break;
        case 4:
            printf("goodbye\n");
            break;
        default:
            printf("NOT\n");
            break;
    }
    return 0;
}
