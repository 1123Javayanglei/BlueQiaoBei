//
//  main.c
//  散列运算
//
//  Created by 杨磊 on 2019/5/20.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    const int mumber =10;
    int x;
    int count [mumber];
    int i;
    for (i=0; i<mumber; i++) {
        count[i]=0;
    }
    scanf("%d",&x);
    while (x!=1) {
        if (x>=0 && x<=9) {
            count[x]++;
        }
        scanf("%d",&x);
    }
    for (i=0; i<mumber; i++) {
        printf("%d:%d",i,count[i]);
    }
    return 0;
}
