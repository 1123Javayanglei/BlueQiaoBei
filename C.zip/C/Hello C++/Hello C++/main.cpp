//
//  main.cpp
//  Hello C++
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;
int main()
{
    
    return 0;
}
