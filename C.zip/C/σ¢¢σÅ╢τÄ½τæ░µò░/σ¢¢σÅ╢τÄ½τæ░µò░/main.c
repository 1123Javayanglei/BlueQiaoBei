//
//  main.c
//  四叶玫瑰数
//
//  Created by 杨磊 on 2019/5/14.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int num;
    int a,b,c,d;
    printf("四叶玫瑰数:\n");
  /*
    printf("%d\n",1634 % 10);
    printf("%d\n",1634 /10 % 10);
    printf("%d\n",1634 /100 % 10);
    printf("%d\n",1634 /1000 % 10);
   */
    for (num=1000; num<=9999; num++) {
        a=num % 10;
        b=num /10 %10;
        c=num /100 % 10;
        d=num /1000 % 10;
        if (num==(a*a*a*a+b*b*b*b+c*c*c*c+d*d*d*d)) {
            printf("%d\n",num);
        }
    }
    return 0;
}
