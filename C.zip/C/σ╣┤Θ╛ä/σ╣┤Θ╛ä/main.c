//
//  main.c
//  年龄
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    const int MINOR =35;
    
    int age =0;
    
    printf("Please your age:\n");
    scanf("%d",&age);
    
    printf("Your are age is %d\n",age);
    
    if (age<MINOR) {
        printf("young is will!\n");
    }
    
    printf("Age is your is Z,zheng xi ba\n");
    return 0;
}
