//
//  main.c
//  算数运算
//
//  Created by 杨磊 on 2019/5/12.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a,b;
    printf("请输入两个整数:\n");
    scanf("%d %d",&a,&b);
    printf("sum:%d\n",a+b);
    printf("cha:%d\n",a-b);
    printf("ji:%d\n",a*b);
    printf("shang:%0.2f\n",(float)a / (float)b); //强制类型转换
    printf("yu:%d\n",a % b);
    return 0;
}
