//
//  main.c
//  搜索
//
//  Created by 杨磊 on 2019/5/21.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int seach(int key,int a[],int lenght);

int main(void)
{
    int a[]={2,4,6,7,1,3,5,9,11,13,23,14,32,5,55,43,5,26,76,87,};
    int x;
    int loc;
    printf("请输入一个数字: ");
    scanf("%d",&x);
    loc=seach(x, a, sizeof(a)/sizeof(a[0]));
    if (loc != -1) {
        printf("%d在第%d个位置上\n",x,loc+1);
    } else {
        printf("%d不存在\n",x);
    }
    return 0;
}

int seach(int key,int a[],int lenght)
{
    int ret =-1;
    for (int i=0; i< lenght; i++) {
        if (a[i] == key) {
            ret =i;
            break;
        }
    }
    return ret;
}

