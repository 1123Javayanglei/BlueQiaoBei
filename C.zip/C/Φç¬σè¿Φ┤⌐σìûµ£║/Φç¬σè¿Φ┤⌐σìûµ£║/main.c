//
//  main.c
//  自动贩卖机
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{

    int drink;
    printf("*********************************\n");
    printf("**          Choose On          **\n");
    printf("**         1.Coffee            **\n");
    printf("**         2.Tea               **\n");
    printf("**         3.Coca-Cola         **\n");
    printf("*********************************\n");
    printf("Please input 1 or 2 or 3:\n");
    scanf("%d",&drink);
    printf("Your choose :%d\n",drink);
    switch (drink) {
        case 1:
            printf("Give your coffee\n");
            break;
        case 2:
            printf("Give your tea\n");
            break;
        case 3:
            printf("Give your coca-cola\n");
            break;
        default:
            printf("Thanks you\n");
            break;
    }
    return 0;
}
