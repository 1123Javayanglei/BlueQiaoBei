//
//  main.c
//  猜数游戏
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

/*
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
void menu()
{
    printf("**********************\n");
    printf("****1.play  0.exit****\n");
    printf("**********************\n");
}
void play_game()
{
    int tmp = 0;
    int rand_n = rand() % 100;          //使随机数的大小在0-100之间
    while (1)
    {
        printf("请输入你猜的数>>:");
        scanf("%d", &tmp);
        if (tmp == rand_n)
        {
            printf("恭喜，猜对了\n");
            break;
        }
        else if (tmp > rand_n)
        {
            printf("猜大了\n");
        }
        else
        {
            printf("猜小了\n");
        }
    }
}

int main()
{
    int input;
    srand((unsigned int)time(NULL));        //产生一个随机数
    do
    {
        menu();
        printf("请选择>>:");
        scanf("%d", &input);
        switch (input)
        {
            case 1:
            {
                play_game();
                break;
            }
            case 0:
            {
                exit(EXIT_SUCCESS);
                break;
            }
            default:
            {
                printf("error\n");
                continue;
            }
        }
    } while (input);
    return 0;
}
*/

//#include <stdio.h>
//#include <stdlib.h>
//#include <time.h>
//int main()
//{
//    srand( (unsigned int) time(NULL) );  //使用系统定时器的值作为随机种子
//    int a=0;
//    int number =rand()%100; //获得 0~100 的随机数
//    int count =0;
//    printf("请猜一猜这个1~100的数字:\n");
//    do {
//
//        scanf("%d",&a);
//        count++;
//        if (a>number) {
//            printf("太大了吆\n");
//        }else if (a<number)
//        {
//            printf("太小了撒\n");
//        }
//    } while (a != number);
//    printf("太好了,你用了%d次就猜到了!\n",count);
//    return 0;
//}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    srand((unsigned int) time(NULL));
    int a=0;
    int number=rand()%100;
    int cont=0;
    printf("请猜一猜这个1~100的数字\n");
    do {
        scanf("%d",&a);
        cont++;
        if (a>number) {
            printf("太大了\n");
        } else if (a<number)
        {
            printf("大小了\n");
        }
    } while (a!=number);
    printf("你用了%d次就猜到了数字\n",cont);
    return 0;
}
