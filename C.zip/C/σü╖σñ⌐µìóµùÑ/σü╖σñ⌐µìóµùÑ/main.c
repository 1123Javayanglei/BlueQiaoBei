//
//  main.c
//  偷天换日
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int sum(int a,int b)
{
    int t=0;
    t=a;
    a=b;
    a=t;
    printf("%d %d\n",a,b);
    return 0;
}

int main()
{
    int a,b;
    printf("please enter two number:\n");
    scanf("%d %d",&a,&b);
    a =a^b; // 二进制: (01)1^(11)10=11 十进制:3
    b=b^a; //   二进制: (10)2^(11)3=01 十进制:1
    a=a^b; //   二进制: (11)3^(01)1=10 十进制:2
    printf("%d %d\n",a,b);
    sum(a, b);
    return 0;
}
