//
//  main.c
//  自守数
//
//  Created by 杨磊 on 2019/5/23.
//  Copyright © 2019 Yang. All rights reserved.
//
/*
 案例设计:
 1.for 遍历1~10000
 2.求出此循环中此数的平方和次数的位数
 3.通过对此数的平方取余求出此数的尾数
 4.判断尾数是否和次数相等,如果相等则为自守数
 */

//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int i,a,k,m;
//    for (i=1; i<10000; i++) {        //此数为i
//            {a=i;}               // a=i
//                a*=a;               //a=a*a ----> a=i*i
//                k=log10(i)+1;          //log10(i)+1 ,  求出i的位数
//        for (m=1; k; k--)
//            { m*=10;}
//                a%=m;    //取余找出尾数
//        if (a==i)
//            {printf("%d\n",i);}
//    }
//    return 0;
//}

#include <stdio.h>
#include <math.h>

int main()
{
    int i,a,k,m;
    for (i=1; i<10000; i++) {
        a=i;
        a*=a;
        k= log10(i)+1;
        for (m=1; k; k--)
            m*=10;
            a%=m;
        if (a==i)
            printf("%d\n",i);
        
    }
    return 0;
}
