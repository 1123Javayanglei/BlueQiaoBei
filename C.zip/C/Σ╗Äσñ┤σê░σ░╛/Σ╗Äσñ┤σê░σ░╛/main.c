//
//  main.c
//  从头到尾
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>
int main()
{
    int num,a,b,c;
    printf("请输入一个三位数的整数:\n");
    scanf("%d",&num);
    a = num % 10;   //个位数
    b=num /10 %10;  //十位数
    c=num /100;     //百位数
    printf("个位数=%d\n",num %10);
     printf("十位数=%d\n",num /10 %10);
     printf("百位数=%d\n",num /100);
    printf("倒叙输出:%d\n",100*a+10*b+c);
    printf("从头到位:%d\n",c*100+b*10+a);
    return 0;
}
