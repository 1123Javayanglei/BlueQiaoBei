//
//  main.c
//  求周长和面积
//
//  Created by 杨磊 on 2019/5/12.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
//    float r,s,l;
//    printf("请输入r:\n");
//    scanf("%f",&r);
//    s=3.14*r*r;
//    l=2*r*3.14;
//    printf("面积为=%0.2f\n",s);
//    printf("周长为=%0.2f\n",l);
    int a,b;
//    scanf("%d",&a);
//    scanf("%d",&b);
    scanf("%d %d",&a,&b);
    printf("%d\n",a*b);
    return 0;
}
