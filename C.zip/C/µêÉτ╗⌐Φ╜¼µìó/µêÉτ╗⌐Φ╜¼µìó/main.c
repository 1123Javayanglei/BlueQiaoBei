//
//  main.c
//  成绩转换
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    printf("Please enter one number:\n");
    int i;
    scanf("%d",&i);
    printf("Your enter is a:%d\n",i);
    i/=10;
    switch (i) {
        case 10:
        case 9:
            printf("A\n");
            break;
        case 8:
            printf("B\n");
            break;
        case 7:
            printf("C\n");
            break;
        case 6:
            printf("D\n");
            break;
        case 5:
            printf("E\n");
            break;
        default:
            printf("F\n");
            break;
    }
    return 0;
}
