//
//  main.c
//  时间差
//
//  Created by 杨磊 on 2019/5/13.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int h1,m1;
    int h2,m2;
    printf("请输入两个时间,用空格隔开:\n");
    
    scanf("%d %d",&h1,&m1);
    scanf("%d %d",&h2,&m2);
    
    int ih = h2 - h1;
    int im = m2 - m1;
    
    if (im <0) {
        im = 60+im;
        ih--;
    }
    
    printf("时间是:%d小时,%d分钟\n",ih,im);
    return 0;
}
