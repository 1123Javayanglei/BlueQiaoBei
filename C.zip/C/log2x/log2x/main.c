//
//  main.c
//  log2x
//
//  Created by 杨磊 on 2019/5/15.
//  Copyright © 2019 Yang. All rights reserved.
//

#include <stdio.h>

int main()
{
    int x=0;
    int ret =0;
   // scanf("%d",&x);
    x=128;
    int t =x;
    while (x>1) {
        x/=2;
        ret++;
    }
    printf("log2 of %d is %d.\n",t,ret);
    return 0;
}
