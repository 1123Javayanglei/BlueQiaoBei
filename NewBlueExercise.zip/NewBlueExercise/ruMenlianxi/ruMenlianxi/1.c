////
////  main.c
////  ruMenlianxi
////
////  Created by 杨磊 on 2019/10/22.
////  Copyright © 2019 Yang. All rights reserved.
////
//
//
//
//
///*
//
// 求1+2+3+...+n的值。
//
//    90%
// */
//
//
////#include <stdio.h>
////
////int main(int argc, const char * argv[]) {
////    // insert code here...
////    long long n;
////    long long sum=0;
////    scanf("%lld",&n);
////    if (n>=1 && n<=100000000) {
////        int i;
////        for (i=1; i<=n; i++) {
////            sum+=i;
////        }
////        printf("%lld",sum);
////
////    }
////    return 0;
////}
////
////
//
///*
// 输入两个整数A和B
//
// 范围不超过2^10
//
// 1 1
// 10 20
//
// 2
// 30
//
// */
//
////#include<stdio.h>
////int main()
////{
////    int a=0,b=0;
////    while(~scanf("%d%d", &a, &b))   //下面有关于~的解析
////    {
//
////        printf("%d\n",a+b);
////    }
////    return 0;
////}
//
///*
// **************************
// Hello World!
// **************************
// */
//
////#include <stdio.h>
////int main()
////{
////    printf("**************************\n");
////    printf("Hello World!\n");
////    printf("**************************\n");
////    return 0;
////}
//
///*
// 题目描述
// 编写一个程序，输入a、b、c三个值，输出其中最大值。
// 输入
// 一行数组，分别为a b c
// 输出
// a b c其中最大的数
// 样例输入
// 10 20 30
// 样例输出
// 30
// */
//
////#include <stdio.h>
////int main()
////{
////    int a,b,c,max;
////    scanf("%d%d%d",&a,&b,&c);
////    if (a>b && a>c) {
////        max=a;
////    }else if (b>a && b>c){
////        max=b;
////    }else if (c>a && c>b){
////        max=c;
////    }
////    printf("%d",max);
////    return 0;
////}
////
//
///*
// 1003 密码破译
//
// */
////#include <stdio.h>
////int main(){
////    char c1,c2,c3,c4,c5;
////    scanf("%c%c%c%c%c",&c1,&c2,&c3,&c4,&c5);
////    printf("%c%c%c%c%c",c1+4,c2+4,c3+4,c4+4,c5+4);
////    return 0;
////}
///*
// 母牛的故事
//
// 有一头母牛，它每年年初生一头小母牛。每头小母牛从第四个年头开始，每年年初也生一头小母牛。请编程实现在第n年的时候，共有多少头母牛？
//
//1 2 3 4 5 6 7(年)
//1 1 1
//
// n=1,2,3,时候 只有一只
//
// n=4时，有两只
//
//* V1.递归
///*
// #include <stdio.h>
// int cow(int n){
// if (n<=4) {
// return n;
// }else{
// return cow(n-1)+cow(n-3);
// }
// }
// int main(){
// int n;
// while (~scanf("%d",&n)) {
// if (n>0 && n<55) {
// printf("%d\n",cow(n));
// }
// }
// return 0;
// }
//
//
//  V2.递推
//
// #include <stdio.h>
// int main(){
// int n;
// int f[56]={0,1,2,3};
// for (int i = 4; i <= 55; i++)
// {
// f[i]=f[i-1]+f[i-3];
// }
// while (~scanf("%d",&n) && n!=0) {
// printf("%d\n",f[n]);
// }
// return 0;
//
// }
// */
//
///*
// 温度转换  f（华氏） c=5(F-32)/9
//
// int F
//
// output C
// */
//#include <stdio.h>
//int main()
//{
//    float f;
//    scanf("%f",&f);
//    printf("%.2f",(5*(f-32))/9);
//    return 0;
//}
//
///*
// 三个数找最大值
// */
//
////#include <stdio.h>
////int main()
////{
////    int a,b,c,max;
////    scanf("%d%d%d",&a,&b,&c);
////    if (a>b && a>c) {
////        max=a;
////    }else if (b>a && b>c){
////        max=b;
////    }else{
////        max=c;
////    }
////    printf("%d",max);
////    return 0;
////}
//
//
///*
// 分段函数
//
// x<1 x
// x>=1 && x<10 2x-1
// x>=10 3x-11
// */
////#include <stdio.h>
////int main()
////{
////    int x;
////    scanf("%d",&x);
////    if (x<1) {
////        printf("%d",x);
////    }else if (x>=1 & x<10){
////        printf("%d",2*x-1);
////    }else{
////        printf("%d",3*x-11);
////    }
////    return 0;
////}
////
//
///*
// n<60 E
// n>=60 && n<=69 D
//n>=70 && n<=79 C
//n>=80 && n<=89 B
// n>=90 A
// */
////#include <stdio.h>
////int main()
////{
////    int n;
////    scanf("%d",&n);
////    if (n>=0 && n<=100) {
////        if (n<60) {
////            printf("E");
////        }else if (n>=60 && n<=69){
////            printf("D");
////        }else if (n>=70 && n<=79){
////            printf("C");
////        }else if (n>=80 && n<=89){
////            printf("B");
////        }else{
////            printf("A");
////        }
////    }
////    return 0;
////}
//
///*
// input 1~9999
// output  用数组放
//    1.位数
//    2.逆序
//    3.原数
// */
//#include <stdio.h>
//int main()
//{
//	int number;
//	scanf("%d",&number);
//	int numberlong=number;
//	int c=0;
//	while (numberlong!=0) {
//		numberlong/=10;
//		c++;
//	}
//	printf("%d\n",c);
////	if (number<100000) {			//判断位数
////		int numberlong;
////		if ((number/10000)!=0) {
////			numberlong=5;
////		}else if (((number/1000)%10)!=0) {
////			numberlong=4;
////		}else if ((number/100%10) !=0) {
////			numberlong=3;
////		}else if ((number/10%10)!=0) {
////			numberlong=2;
////		}else if ((number%10)!=0) {
////			numberlong=1;
////		}
////		printf("%d\n",numberlong);  //位数
//		char numberShu[10];
//		sprintf(numberShu,"%d",number);        //把数字转换为字符数组
//		for (int j=0; j<c; j++) {      //输出
//			printf("%c ",numberShu[j]);
//		}
//		printf("\n");
//		for (int i=(c-1); i>=0; i--) {   //从后向前输出
//			printf("%c",numberShu[i]);
//		}
////	}
//	return 0;
//}
//
//
//
///*
// 输入2个整数，求两数的平方和并输出。
// */
////#include <stdio.h>
////int main()
////{
////	int a,b;
////	scanf("%d%d",&a,&b);
////	printf("%d",(a*a)+(b*b));
////	return 0;
////}
//
//
///*
// 题目很简单，已知半径r，求一个圆的面积是多大。
//
// 公式不用提了吧~~
//
// 输入
// 输入一个半径，浮点类型~
// 输出
// 输出它对应的面积大小，保留两位小数哦！
// */
//
////#include <stdio.h>
////#include <math.h>
////#define PI acos(-1)  //acos(-1) == pi
////int main()
////{
////	float r;
////	scanf("%f",&r);
////	printf("%.2f",PI*r*r);
////	return 0;
////}
//
///*
// 输入一个长方形的长和宽（整数），输出该长方形的周长C和面积S，要求格式如例（请注意打印“C:”、“S:”，使用半角冒号，参考样例输出）。
// */
////#include <stdio.h>
////int main()
////{
////	int a,b;
////	scanf("%d %d",&a,&b);
////	printf("C:%d\nS:%d",(a+b)*2,a*b);
////	return 0;
////}
////
//
///*
// 输入三个整数，按由小到大的顺序输出。
// */
//
////#include <stdio.h>
////
////void paoPao(int arr[],int n){
////	 int i,j;
////		   int temp=0;
////		   for (i=0; i<n-1; i++) {
////			   for (j=0; j<n-i-1; j++) {
////				   if (arr[j]>arr[j+1]) {
////					   temp=arr[j];
////					   arr[j]=arr[j+1];
////					   arr[j+1]=temp;
////				   }
////			   }
////		   }
////	   }
////int main()
////{
////	int arr[3];
////	int i,j;
////	for (i=0; i<3; i++) {
////		scanf("%d",&arr[i]);
////	}
//////	MaoPao(arr,3);
////	paoPao(arr, 3);
////	for (j=0; j<3; j++) {
////		printf("%d ",arr[j]);
////	}
////	return 0;
////}
//
//
///*
// 企业发放的奖金根据利润提成。利润低于或等于100000元的，奖金可提10%;
// 利润高于100000元，低于200000元（100000<I≤200000）时，低于100000元的部分按10％提成，高于100000元的部分，可提成 7.5%;
// 200000<I≤400000时，低于200000元部分仍按上述办法提成，（下同），高于200000元的部分按5％提成；
// 400000<I≤600000元时，高于400000元的部分按3％提成；
//
// 600000<I≤1000000时，高于600000元的部分按1.5%提成；
// I>1000000时，超过1000000元的部分按1%提成。从键盘输入当月利润I,求应发奖金总数。
// */
//#include "stdio.h"
//int main(){
//	int liRun,jiangJin;
//	scanf("%d",&liRun);
//	if (liRun<=100000) {
//		jiangJin=liRun*0.1;
//	}else if (liRun>100000 && liRun<=200000){
//		jiangJin=(liRun-100000)*0.075+100000*0.1;
//	}else if (liRun>200000 && liRun<=400000){
//		jiangJin=(liRun-200000)*0.05+(100000)*0.1+(100000)*0.075;
//	}else if (liRun>400000 && liRun<=600000){
//		jiangJin=(liRun-400000)*0.03+200000*0.05+100000*0.075+100000*0.1;
//	}else if(liRun>600000 && liRun<=1000000){
//		jiangJin=(liRun-600000)*0.015+200000*0.03+200000*0.05+100000*0.075+100000*0.1;
//	}else{
//		jiangJin=(liRun-1000000)*0.01+400000*0.015+200000*0.03+200000*0.05+100000*0.075+100000*0.1;
//	}
//	printf("%d",jiangJin);
//	return 0;
//}
//
//
///*
// 输入10个整数，求它们的平均值，并输出大于平均值的数据的个数。
// */
//#include <stdio.h>
//int main()
//{
//	int arr[11];
//	for (int i=0; i<10; i++) {
//		scanf("%d",&arr[i]);
//	}
//	int a,b,c,d,e,f,g,h,i,j,k;
//	a=arr[0];
//	b=arr[1];
//	c=arr[2];
//	d=arr[3];
//	e=arr[4];
//	f=arr[5];
//	g=arr[6];
//	h=arr[7];
//	i=arr[8];
//	j=arr[9];
//	k=(a+b+c+d+e+f+g+h+i+j)/10;
//	int con=0;
//	for (int j=0; j<10; j++) {
//		if (arr[j]>k) {
//			con++;
//		}
//	}
//	printf("%d",con);
//	return 0;
//}
//
///*
// 判断一个数是否为"水仙花数"，所谓"水仙花数"是指这样的一个数：首先是一个三位数，其次，其各位数字的立方和等于该数本身。例如：371是一个"水仙花数"，371=3^3+7^3+1^3.
// */
//
//#include <stdio.h>
//int main(){
//	int input;
//	scanf("%d",&input);
//	int ge,shi,bai;
//	ge=input%10;
//	shi=input/10%10;
//	bai=input/100;
//	if ((ge*ge*ge+shi*shi*shi+bai*bai*bai)==input) {
//		printf("1");
//	}else{
//		printf("0");
//	}
//	return 0;
//}
//
//#include <stdio.h>
//int main(){
//
//	int ge,shi,bai;
//
//	for (int input=100; input<=999; input++) {
//		ge=input%10;
//		shi=input/10%10;
//		bai=input/100;
//		if ((ge*ge*ge+shi*shi*shi+bai*bai*bai)==input) {
//			printf("%d\n",input);
//		}
//	}
//	return 0;
//}
//
///*
// 编制程序，输入n个整数（n从键盘输入，n>0），输出它们的偶数和。
// */
//#include <stdio.h>
//int main()
//{
//	int input;
//	int sum=0;
//	scanf("%d",&input);
//	int arr[input];
//	for (int i=0; i<input; i++) {
//		scanf("%d",&arr[i]);
//	}
//	for (int j=0; j<input; j++) {
//		if (arr[j]%2==0) {
//			sum+=arr[j];
//		}
//	}
//	printf("%d",sum);
//	return 0;
//}
//
//
///*
// sum=2+5+8+11+14+…，输入正整数n，求sum的前n项和。
// 1 2 3  4  5  6  8  9  10 11 12
// 2 5 8 11 14 17 20 22 24 26
// (n-1)+3
// */
//#include <stdio.h>
//int  dengCha(int n){
//	if (n==1) {
//		return 2;
//	}else{
//		return dengCha(n-1)+3;
//	}
//}
//int main(){
//	int input;
//	int sum=0;
//	scanf("%d",&input);
//	for (int i=1; i<=input; i++) {
//		sum+=dengCha(i);
//	}
//
//	printf("%d",sum);
//	return 0;
//}
//
///*
// 求以下三数的和,保留2位小数 1~a之和 1~b的平方和 1~c的倒数和
// 输入
// a b c
// 输出
// 1+2+...+a + 1^2+2^2+...+b^2 + 1/1+1/2+...+1/c
// 样例输入
// 100 50 10
// 样例输出
// 47977.93
// */
//#include <stdio.h>
//int main()
//{
//	float a,b,c;
//	scanf("%f%f%f",&a,&b,&c);
//	float sum=0;
//	float pingFang=0;
//	float daoShu=0;
//	for (int i=1; i<=a; i++) {
//		sum+=i;
//	}
//	for (int j=1; j<=b; j++) {
//		pingFang+=j*j;
//	}
//	for (int k=1; k<=c; k++) {
//		daoShu+=1.0/k;     			//1.0 重点 计算除法时，和左边有关，和右边无关，取模同理
//	}
////	printf("%0.2f\n",sum);
////	printf("%0.2f\n",pingFang);
////	printf("%0.2f\n",daoShu);
//	printf("%0.2f\n",sum+pingFang+daoShu);
//	return 0;
//}
//
//
///*
// 输入两个正整数m和n，求其最大公约数和最小公倍数。
// */
//
//#include <stdio.h>
///*
// function gcd(a, b)
//  while b ≠ 0
//	 t ← b
//	 b ← a mod b
//	 a ← t
// return a
// */
//int  gcd_chufa ( int  m , int  n )  //除法
//{
//        int  t  =  1 ;
//        while ( t  !=  0 )
//        {
//                t = m % n ;
//                m = n ;
//                n = t ;
//        }
//        return  m ;
//}
//int  gcd_digui ( int  n , int  m )  //递归
// {
//         if ( m == 0 )
//                 return  n ;
//         else
//                 return  gcd_digui ( m , n % m );
// }
//int main()
//{
//	int m,n;
//	scanf("%d%d",&m,&n);
////	printf("%d\n",gcd_chufa(m, n));
////	只需要先求出最大公约数。用两个数的乘积除以最大公约数即可。
//
//	printf("%d %d",gcd_digui(m, n),(m*n)/(gcd_digui(m, n)));
//	return 0;
//}
//
//
///*
// 有一分数序列： 2/1 3/2 5/3 8/5 13/8 21/13...... 求出这个数列的前N项之和，保留两位小数。
// 输入
// N
// 输出
// 数列前N项和
// 分子：
// 2 3 5 8 13 21
// n=1 R 2
// else R (F-1)+(F-2)
//
// 分母:
// 1 2 3 5 8 13
//
// */
//
//#include <stdio.h>
//double fenZi(double n){
//	if (n==1.0) {
//		return 2;
//	}else if (n==2){
//		return 3;
//	}else{
//		return (fenZi(n-1)+fenZi(n-2));
//	}
//}
//double fenMu(double n){
//	if (n==1) {
//		return 1;
//	}else if (n==2){
//		return 2;
//	}else{
//		return fenMu(n-1)+fenMu(n-2);
//	}
//}
//int main()
//{
//	double  n;
//	double sum=0;
//	scanf("%lf",&n);
//	for (int i=1; i<=n; i++){
//
//
//		sum+=fenZi(i)/fenMu(i);  	//傻逼，你跑n有啥用？？？？
//	}
//	printf("%0.2lf",sum);
//	return 0;
//}
//
///*
// 一球从M米高度自由下落，每次落地后返回原高度的一半，再落下。 它在第N次落地时反弹多高？共经过多少米？ 保留两位小数
//
// */
//
//#include <stdio.h>
//
//int main()
//{
//	double m,n;						//m=米	n=次
//	scanf("%lf%lf",&m,&n);			//input 米，
//	double sum;						//sum 求和
//	sum=m;							//第一次落下 sum=m
//	for (double i=1; i<=n; i++) {
//		m=m/2;						//每次落地返回原高度的一半
//		sum+=m*2;					//落上+落下的 赋值给sum
//	}
//	sum-=m*2;
//	printf("%0.2lf %0.2lf",m,sum);
//	return 0;
//}
//
//
///*
// 猴子吃桃
// */
//
//#include <stdio.h>
//#include <math.h>
//int main()
//{
//	double N;
//	scanf("%lf",&N);
//	printf("%0.0lf", (pow(2,N-2)*3-1)*2 );
//	return 0; //}
//
///*
// 拆分位数
// */
//#include <stdio.h>
//int main()
//{
//	int san,a,b,c;
//	scanf("%d",&san);
//	if (san>=100 && san<=999) {
//		a=san%10;
//		b=san/10%10;
//		c=san/100;
//		printf("%d %d %d",a,b,c);
//	}
//
//	return 0;
//}
//
///*
// 小99
//
// */
//
//#include <stdio.h>
//int main()
//{
//	for (int i=1; i<=9; i++) {
//		for (int j=1; j<=i; j++) {
//			printf("%d*%d=%-2d ",j,i,i*j);  // %-2d
//		}
//		printf("\n");
//	}
//	return 0;
//}
//
///*
// 求出10至1000之内能同时被2、3、7整除的数，并输出。
//
// 每行一个。
// */
//
//#include <stdio.h>
//int main(){
//	for (int i=10; i<=1000; i++) {
//		if ((i%2==0) && (i%3==0) && (i%7==0)) {
//			printf("%d\n",i);
//		}
//	}
//	return 0;
//}
//
//
///*
// 从键盘输入任意20个整型数，统计其中的负数个数并求所有正数的平均值。
//
// 保留两位小数
// */
//
//#include <stdio.h>
//int main()
//{
//	int arr[20];
//	int c=0;
//	double sum=0.0;
//	for (int i=0; i<20; i++) {
//		scanf("%d",&arr[i]);
//		if (arr[i]>=0) {
//			sum+=(double)arr[i];
//		}else{
//			c++;
//		}
//	}
//	printf("%d\n",c);
//	printf("%.2lf\n",sum/(20-c));
////	printf("%f\n",(5+ 87+ 4+ 3+ 1+ 7+ 8+ 9+ 5+ 4+ 3+ 1+ 4+ 7+  8+ 4+ 8+ 9+ 2.0)/(20-c));
//	return 0;
//}
// 测试	5 87 4 3 1 7 8 9 5 4 3 1 4 7 -9 8 4 8 9 2 9.4210526316
//
///*
// 已有一个已正序排好的9个元素的数组，今输入一个数要求按原来排序的规律将它插入数组中。
// 1 7 8 17 23 24 59 62 101  从小到大
// 0 1 2 3  4	 5  6  7  8
//
// 50
// */
//
//#include <stdio.h>
//void paopao(int *a){
//	int temp;
//	int i,j;
//	for (i=0 ; i<10; i++) {     //外部循环控制所有的回合
//		for (j=0; j<10-i-1; j++) {	//内部循环代表每一轮的冒泡处理
//			if (a[j]>a[j+1]) {
//				temp=a[j];
//				a[j]=a[j+1];
//				a[j+1]=temp;
//			}
//		}
//	}
//}
//
//int main()
//{
//	int a[10];
//	for (int i=0; i<9; i++) {
//		scanf("%d",&a[i]);
//	}
//	scanf("%d",&a[9]);
//	paopao(a);
//	for (int k=0; k<10; k++) {
//		printf("%d\n",a[k]);
//	}
//	return 0;
//}
//
//
//
///*
// 逆序输出
// */
//#include <stdio.h>
//
//int main()
//{
//	int a[10];
//	for (int i=0; i<10; i++) {
//		scanf("%d",&a[i]);
//	}
//	for (int k=9; k>=0; k--) {
//		printf("%d ",a[k]);
//	}
//	return 0;
//}
//
///*
// 求一个3×3矩阵对角线元素之和。
// */
//#include <stdio.h>
//int main()
//{
//	int zhu=0;
//	int fu=0;
//	int arr[3][3];
//	for (int i=0; i<3; i++) {
//		for (int j=0; j<3; j++) {
//			scanf("%d",&arr[i][j]);
//			if (i==j) {
//				zhu+=arr[i][j];
//			}
//			if (i+j==2) {
//				fu+=arr[i][j];
//			}
//		}
//	}
//	printf("%d %d",zhu,fu);
//
//}
//
///*
// 求矩阵的两对角线上的元素之和
// */
//#include <stdio.h>
//int main()
//{
//	int zhu=0;
//	int n;
//	scanf("%d",&n);
//	int arr[n][n];
//	for (int i=0; i<n; i++) {
//		for (int j=0; j<n; j++) {
//			scanf("%d",&arr[i][j]);
//			if (i==j ||(i+j==(n-1)) ) {
//				zhu+=arr[i][j];
//			}
//		}
//	}
//	printf("%d",zhu);
//
//}
//
//
//  gcd 最大公约数最小公倍数
//#include <stdio.h>
//int  gcd ( int  n , int  m )  //递归
// {
//	 if ( m == 0 ){
//		 return  n ;
//	 }else{
//		 return  gcd ( m , n % m );
//	 }
// }
//int main()
//{
//	int m,n;
//	scanf("%d%d",&m,&n);
//	printf("%d %d",gcd(m, n),(m*n)/(gcd(m, n)));
//	return 0;
//}
//
//
///*
// 求方程 的根，用三个函数分别求当b^2-4ac大于0、等于0、和小于0时的根，并输出结果。从主函数输入a、b、c的
// 一元二次方程
// ax²+bx+c=0   (a≠0)
// 1. Z>0
// X1=((-b+sqrt(pow(b,2)-4*a*c)))/2*a)
// X1=((-b-sqrt(pow(b,2)-4*a*c)))/2*a)
//
// 2.Z=0
// X1=X2=((-b+sqrt(pow(b,2)-4*a*c)))/2*a)
//
// 3.Z<0	两个共轭复根
// X1=(-b/2*a)+((sqrt(4*a*c-pow(b,2)))/2*a)*i
// X2=(-b/2*a)-((sqrt(4*a*c-pow(b,2)))/2*a)*i
//
// pow(i,2)=-1  i=sqrt(-1)
//
//
//
// 其求根依据判定式△的取值为三种   ( △=b²-4ac )
//
// 1. △>0，方程有两个不相等的实数根；
//
// x1=[-b+√(△)]/2a;   ( △=b²-4ac )
// x2=[-b-√(△)]/2a;
//
// 2. △=0，方程有两个相等的实数根；
// x1=x2=[-b+√(△)]/2a= -b/2a ;
//
// 3. △<0，方程无实数根，但有2个共轭复根。
// x1=[-b+√(△)*i]/2a;   ( △=b²-4ac )
// x2=[-b-√(△)*i]/2a;
// */
//#include <stdio.h>
//#include <math.h> //sqrt(double);
//float x1,x2,a,b,c,z,p,q;
//void fun1(){ // >0
//	x1=(-b+sqrt(z))/(2*a);
//	x2=(-b-sqrt(z))/(2*a);
//}
//void fun2(){	// <0
//	p=-b/(2*a);
//	q=(sqrt(4*a*c-b*b))/(2*a);
//	printf("x1=%.3lf+%.3lfi x2=%.3lf-%.3lfi\n",p,q,p,q);
//}
//void fun3(){		//=0
//	x1=x2=(-b)/(2*a);
//}
//int main()
//{
//	scanf("%f%f%f",&a,&b,&c);
//	z=b*b-(4*a*c);  //△
//	if (z>0) {
//		fun1();
//	}else if (z<0){
//		fun2();
//		return 0;
//	}else{
//		fun3();
//	}
//	printf("x1=%.3f x2=%.3f\n",x1,x2);
//	return 0;
//}
//
//
///*
// 写一个判断素数的函数，在主函数输入一个整数，输出是否是素数的消息。
// 输入
// 一个数
// 输出
// 如果是素数输出prime 如果不是输出not prime
// */
///*
// 素数就是仅能被1和它自身整除的整数。判定一个整数n是否为素数就是要判定整数n能否被除1和它自身之外的任意整数整除，若都不能整除，则n为素数。
// */
//#include <stdio.h>
//int main()
//{
//	int iput;
//	int c=0;
//	scanf("%d",&iput);
//	for (int i=2;i<iput; i++) {
//		if( (iput % i)!=0){
//			c++;
//		}
//	}
//	if (c==(iput-2)) {
//		printf("prime");
//	}else{
//		printf("not prime");
//	}
//	return 0;
//}
//
///*
// 写一个函数，使给定的一个二维数组（３×３）转置，即行列互换。
// */
//#include <stdio.h>
//int main()
//{
//	int arr[3][3];
//	for (int q=0; q<3; q++) {
//		for (int w=0; w<3; w++) {
//			scanf("%d",&arr[q][w]);
//		}
//	}
//	int arrB[3][3];
//	for (int i=0; i<3; i++) {
//		for (int j=0; j<3; j++) {
//			arrB[j][i]=arr[i][j];
//		}
//	}
//	for (int k=0; k<3; k++) {
//		for (int l=0; l<3; l++) {
//			printf("%d ",arrB[k][l]);
//		}
//		printf("\n");
//	}
//	return 0;
//}
//
//
///*
// 写一函数，将一个字符串中的元音字母复制到另一个字符串，然后输出。
// */
//
//#include <stdio.h>
//int main()
//{
//	char arr[999999];
//	scanf("%s",&arr);
//	for (int i=0; arr[i]!='\0'; i++) {
//		if ((arr[i]=='a') || (arr[i]=='e')|| (arr[i]=='i')|| (arr[i]=='o')|| (arr[i]=='u')) {
//			printf("%c",arr[i]);
//		}
//	}
//	return 0;
//}
//
///*
//写一函数，输入一个四位数字，要求输出这四个数字字符，但每两个数字间空格。如输入1990，应输出"1 9 9 0"。
// */
//#include <stdio.h>
//int main()
//{
//	char arr[5];
//	for (int i=0; i<4; i++) {
//		scanf("%c",&arr[i]);
//	}
//	for (int j=0; j<3; j++) {
//		printf("%c ",arr[j]);
//	}
//	printf("%c",arr[3]);
//	return 0;
//}
//
//
///*
//编写一函数，由实参传来一个字符串，统计此字符串中字母、数字、空格和其它字符的个数，在主函数中输入字符串以及输出上述结果。 只要结果，别输出什么提示信息。
// */
//
//#include <stdio.h>
//int main()
//{
//	int a=0; //字母
//	int b=0;	//数字
//	int c=0;	//空格
//	int d=0;	//其他
//	char arr[999];
//	scanf("%[^\n]",arr);  //读到'\n'结束读取,存入str,再抛弃一个字符
//	/*
//	 int c;
//	 while((c=getchar())!='\n'&&c!=EOF);
//	 //读取一个字符，直到是\n或者是EOF停止
//	 //等价于
//	 scanf("*[^\n]");	 */
//	for (int i=0; arr[i]!='\0'; i++) {
//		if  (arr[i]==32){
//			c++;
//		}else if ((arr[i]>=65 && arr[i]<=90)||(arr[i]>=97&&arr[i]<=122))
//		{
//			a++;
//		}else if (arr[i]>=48 && arr[i]<=57) {
//			b++;
//		}else{
//			d++;
//		}
//	}
//	printf("%d %d %d %d",a,b,c,d);
//	return 0;
//}


/*
 输入10个整数，将其中最小的数与第一个数对换，把最大的数与最后一个数对换。写三个函数； ①输入10个数；②进行处理；③输出10个数。
 */

//#include <stdio.h>
//#include <stdlib.h>
//
//void in(int *arr){
//	for (int v=0; v<10; v++) {
//		scanf("%d",&arr[v]);
//	}
//}
//void maxAndMin(int a[],int arr[],int arrb[]){
//
//	int min,max;
//
//	min=a[0];
//	for (int i=0; i<10; i++) {
//		if (a[i]<min) {
//			min=a[i];
//		}
//	}
//
//	max=a[0];
//	for (int k=0; k<10; k++) {
//		if (a[k]>max) {
//			max=a[k];
//		}
//	}
//
////	printf("Max=%d Min=%d \n",max,min);
//
//	//查找出最大值和最小值的位置
//
//	int c=0;
//	while (max!=*a) {
//		a++;
//		c++;
//	}
//
//	int b=0;
//	while (min!=*arr) {
//		arr++;
//		b++;
//	}
//
////	printf("max add=%d min add=%d\n",c,b);
//
//
//	//交换下标
//
//	int tempA,tempB;
//
//
//
//	// max a[9]
//
//
//	tempA=arrb[c];
//
//	arrb[c]=arrb[9];
//
//	arrb[9]=tempA;
//
//
//	// min a[0]
//
//	tempB=arrb[b];
//
//	arrb[b]=arrb[0];
//
//	arrb[0]=tempB;
//
//
////	输出
//
//	for (int j=0; j<10; j++) {
//		printf("%d ",arrb[j]);
//	}
//
////printf("\n");
//
//}
//
//int main()
//{
//
//	int d[10];
//
//	in(d);
//
//	int arr[10];
//
//	int arrB[10];
//
//
//	for (int i=0; i<10; i++) {
//		arr[i]=d[i];
//	}
//
//	for (int i=0; i<10; i++) {
//		arrB[i]=d[i];
//	}
//
//	maxAndMin(d,arr,arrB);
//
//
//	return 0;
//}

/*
 数字后移
 */

//#include<stdio.h>
//
//#include<stdlib.h>
//
//
//int main()
//
//{
//
//	int n,m,i;  //n为长度 m为移动的位置
//	scanf("%d",&n);
//	int a[n];  //数组
//	for(i=0;i<n;i++)
//	{
//		scanf("%d",&a[i]);
//	}
//	scanf("%d",&m);
//	//	A(a,n,m);
//	int tmp;  //定义循环变量tmp
//	for(int j=0;j<m;j++)  //从0开始到m
//	{
//		tmp=a[n-1];				//tem等于a的最后一位
//		for(int i=n-1;i>0;i--)	//从n的最后一位到n的第一位
//		{
//			a[i]=a[i-1];	//
//		}
//		a[0]=tmp;		//把交换前的最后一位给第一位
//	}
//	for(i=0;i<n;i++)
//	{
//		printf("%d ",a[i]);
//	}
//	return 0;
//
//}
//
//
//

/*
 写一函数，使输入的一个字符串按反序存放，在主函数中输入输出反序后的字符串（不包含空格）。
 */

//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	char input[80];
//	scanf("%s",input);
//	int charLong=strlen(input);
//
//	for (int i=charLong-1; i>=0; i--) {
//		printf("%c",input[i]);
//	}
//
//	return 0;
//}


/*
 拼接字符串
 */
//#include <stdio.h>
////char *STRCAT(char *dest, const char *src)
////{
////    char *tmp = dest;
////    while (*dest){
////        dest++;
////    }
////    while ((*dest++ = *src++) != '\0');    //首先dest地址移动到最后一位，然后增加src参数值遇到’\0’结束拷贝。
////    return tmp;
////}
//
////V2.0
//
//char *STRCAT(char *dst, const char *src){
//    char* p=dst;
//    while (*dst!='\0') {
//        *dst++;
//    }
//    while (*src!='0') {
//        *dst++=*src++;
//    }
//    return p;
//}
//
//
//int main()
//{
//	char a[10000];
//    char b[10000];
//	scanf("%s",a);
//	scanf("%s",b);
////    );
//    printf("%s",STRCAT(a, b));
//    return 0;
//}
//

/*
 大小写转换
 */
//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	char iput[100];
//	scanf("%s",iput); //gets(input) 必须用  scanf错误12%
//	for (int i=0; i<strlen(iput); i++) {
//		if (iput[i]>='A' && iput[i]<='Z') {
//			printf("%c",iput[i]+32);
//		}else{
//			printf("%c",iput[i]);
//		}
//	}
//	return 0;
//}


/*
 数字母
 */

//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	char iput[100];
//	int len=0;
////	scanf("%s",iput); //gets(inpt) 必须用  scanf错误12%
//	gets(iput);
//	for (int i=0; i<strlen(iput); i++) {
//		if ((iput[i]>='A' && iput[i]<='Z')||(iput[i]>='a' && iput[i]<='z')) {
//			len++;
//		}
//	}
//	printf("%d",len);
//	return 0;
//}


/*
 输入多行，去空格，长度不超过80
 */

//#include <stdio.h>
//#include <string.h>
//#include<stdlib.h>
//int main()
//{
//	char inpu[80];
//	while (fgets(inpu,81,stdin)!=NULL) {
//		/*
//		 char *fgets(char *str,int n,FILE *stream)
//		从指定的stream读取一行，并且存储在str中，当读到(n-1)个字符或换行或文件末尾时，会停止
//		 */
//		for (int i=0; i<strlen(inpu); i++) {
//			if (inpu[i]!=' ') {					//如果当前不是空格就输入它
//				printf("%c",inpu[i]);
//			}
//		}
//	}
//	return EXIT_SUCCESS;
//}


/*
 电报加密
 */

//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	// a=97 b=98 z=122    a-A=32
//	// A=65 B=66 Z=90
////	printf("%d %d %d",'A','B','Z');
//	char str[100];
////	printf("%d",'Z'+1);
//	gets(str);		//死了亲妈的gets 用scanf就是不对
////	scanf("%s",str);
//	for (int i=0; i<strlen(str); i++) {
//		if (str[i]>='a' &&str[i]<'z') {
//			printf("%c",str[i]+1);
//		}else if (str[i]=='z'){
//			printf("%c",'a');
//		}else if (str[i]>='A' &&str[i]<'Z'){
//			printf("%c",str[i]+1);
//		}else if (str[i]=='Z'){
//		printf("%c",'A');
//		}
//		else{
//			printf("%c",str[i]);
//		}
//	}
//	return 0;
//}


/*
 计算当天是今年的第几天
 */
//#include <stdio.h>
//int main()
//{
//    int year,month,day,yearDay;
//    int i=0;
//    int monthDay_1[12]={31,28,31,30,31,30,31,31,30,31,30,31,};
//    int monthDay_2[12]={31,29,31,30,31,30,31,31,30,31,30,31,};
//    int sum=0;
//    scanf("%d %d %d",&year,&month,&day);
//        if ((year%400==0)||((year%4==0)&&(year%100!=0))) {
//            yearDay=366;
//            for (i=0; i<month-1; i++) {     // -1是为了求到月份对映的数组下标
//                sum+=monthDay_2[i];
//            }
//            sum+=day;
////            printf("%d年的总天数为%d天",year,yearDay);
//            printf("%d",sum);
//        }else{
//
//            if ((month==2)&&(day>28)) {         //防止非法输入
//                return 0;
//            }else{
//                yearDay=365;
//            for (i=0; i<month-1; i++) {
//                           sum+=monthDay_1[i];
//                       }
//                       sum+=day;
////                       printf("%d年的总天数为%d天",year,yearDay);
//                       printf("%d",sum);
//        }
//        }
//    return 0;   //
//}


/*
 第八章 编译和预处理
 */

//#include <stdio.h>
////#include "Header.h"
//#define PI 3.14159
//#define ABS(x) ((x)>=0?(x):(-x))
//#define SWAP(a,b) {int temp;temp=a;a=b;b=temp;}
//#define Win32 0
//#define x64 1
//#define SYSTEM x64
//#define Chu(a,b)(a%b)
//#define S(a,b,c) ((a+b+c)/2)
//#define Area(a,b,c) (((a+b+c)/2)*(((a+b+c)/2)-a)*(((a+b+c)/2)-b)*(((a+b+c)/2)-c))
//int main()
//{
//	double a,b,c;
//	scanf("%lf %lf %lf",&a,&b,&c);
////	S(a,b,c);
//	printf("%0.3lf",Area(a, b, c));
//
//
//
////	SWAP(a,b);
//
////	printf("%d",Chu(a, b));
////	printf("%d\n",ABS(10));
////	INT(arr[0]);
////	printf("***********************\n");
////#if SYSTEM == Win32
////	printf("Win32\n");
////#else
////	printf("x64\n");
////#endif
////	printf("***********************\n");
////	printf("%s",__FUNCTION__);
//	return 0;
//}


/*
 第九章 结构体和共用体
 */
//#include <stdio.h>
//struct Student {
//	char xuehao[20];
//	char xing[20];
//	int one;
//	int tow;
//	int there;
//};
//void input(struct Student *stu,int n){
//	for (int i=0; i<n; i++) {
//		scanf("%s %s %d %d %d",stu[i].xuehao,stu[i].xing,&stu[i].one,&stu[i].tow,&stu[i].there);
//	}
//}
//void print(struct Student *stu,int n){
//	for (int i=0; i<n; i++) {
//		printf("%s,%s,%d,%d,%d\n",stu[i].xuehao,stu[i].xing,stu[i].one,stu[i].tow,stu[i].there);
//	}
//}
//int main()
//{
//	struct Student stu[100];
//	int len;
//	scanf("%d",&len);
//	input(stu, len);
//	print(stu, len);
//	return 0;
//}

/*
 结构体 成绩V2.0
 */
//#include <stdio.h>
//struct Student {
//	char xuehao[20];
//	char xing[20];
//	int one;
//	int tow;
//	int there;
//};
//void input(struct Student *stu,int n){
//	for (int i=0; i<n; i++) {
//		scanf("%s %s %d %d %d",stu[i].xuehao,stu[i].xing,&stu[i].one,&stu[i].tow,&stu[i].there);
//	}
//}
//void count(struct Student *stu,struct Student max[0],int n){
//	int soursOne=0;
//	int sourTow=0;
//	int sourThere=0;
//	for (int i=0; i<n; i++) {  //赋值
//		soursOne+=stu[i].one;
//		sourTow+=stu[i].tow;
//		sourThere+=stu[i].there;
//		if ((stu[i].one>max->one) &&(stu[i].tow>max->tow) && (stu[i].there>max->there)) {
//			max[0]=stu[i];
//		}
//
//	}
//	printf("%d %d %d\n", soursOne/=n,sourTow/=n,sourThere/=n);	//输入平均值
//
//printf("%s %s %d %d %d",max->xuehao,max->xing,max->one,max->tow,max->there);
//}
//int main()
//{
//	struct Student stu[100];
//	int len;
//	scanf("%d",&len);
//	input(stu, len);
//	count(stu,stu,len);
////	print(stu, len);
//	return 0;
//}


/*
 宏定义 ：求三角形的面积
 */
//#include <stdio.h>
//#include <math.h> //海伦公式 sqrt(s(s-a)(s-b)(s-c))  s=(a+b+c)/2
//#define AREA(a,b,c) (sqrt(((a+b+c)/2)*((a+b+c)/2-a)*((a+b+c)/2-b)*((a+b+c)/2-c))
//int main()
//{
//	int a,b,c;
//	scanf("%d%d%d",&a,&b,&c);
//	printf("%0.3lf",AREA(a,b, c)));
//	return 0;
//}

/*
 宏定义：闰年判读
 */

//#include <stdio.h>
//#define LEAP_YEAR(year) ((year%400==0)||((year%4==0)&&(year%100!=0)))?'L':'N'
//int main()
//{
//    int year=0;
//    scanf("%d",&year);
////    if ((year%400==0)||((year%4==0)&&(year%100!=0))) {
////		printf("L");
////    }else{
////		printf("N");
////    }
//	printf("%c",LEAP_YEAR(year));
//    return 0;
//}
//

/*
 宏定义:找最大数量
 */

//#include <stdio.h>
//#define MAX(a,b,c) {double max=0;if(a>b &&a>c){max=a;}else if(b>a && b>c){max=b;}else{max=c;}printf("%.3lf",max);}
//int main()
//{
//    double a,b,c,max;
//    scanf("%lf%lf%lf",&a,&b,&c);
//    if (a>b && a>c) {
//        max=a;
//    }else if (b>a && b>c){
//        max=b;
//    }else{
//        max=c;
//    }
//    printf("%.3lf\n",max);
//	MAX(a, b, c);
//    return 0;
//}

/*
 约瑟夫环
 */
//#include <stdio.h>
//int josephusProblem(int n,int m){  // n is input, m is kill number
////	return n==1?n:(josephusProblem(n-1,m)+m-1)%n+1;
//	if (n==1) {
//		return n;
//	}else{
//		return (josephusProblem(n-1,m)+m-1)%n+1;
//	}
//}
//int main()
//{
//	int n;
//	scanf("%d",&n);
//	printf("%d",josephusProblem(n, 3));
//    return 0;
//}


/*
 Sn的公式求合
 2 22		222			2222

 0	2*11	2*111			2*1111

 11=1*10+1
 111=1*100+1*10+1=10^2+10^1+1
 1111=10^3+10^2+10^1+1
 */

//#include <stdio.h>
//#include <math.h>
//int main()
//{
//	double N=2;
//	double Sn;
//	double Sum=0;
//	scanf("%lf",&Sn);
//	double b=Sn;
////	(10^4+(10^3)*2+10^2*3+10*4+1*5)*2
//	for (int i=1; i<=Sn; i++) {
//		Sum+=N*(i*pow(10, b-1)); //2*(1*10^(5-1)) += 2*(1*10^4) 2*(2*10^3) 2*(3*10^2) 2*(4*10) 2*(5*1)
//		b--;
//	}
//	printf("%.0lf",Sum);
//	return 0;
//}

/*
 Sn 阶乘求和问题
 */

//#include <stdio.h>
//long int jieCheng(int n){
//	int i,j=n;
//    long int sum=1;
//	for(i=1;i<=j;i++){
//        sum*=i;		//阶乘
//    }
//	return sum;
//}
//long int MOD(int a){
//    if (a==0) return 1;
//    return  a*MOD(a-1);
//}
//int main(){
//
//	int Sn;//=1!+2!+3!+4!+5!=153
//	scanf("%d",&Sn);
//	if (Sn<=20) {
//		long int sum=0;
//		for (int i=1; i<=Sn; i++) {
//			sum+=jieCheng(i);
//		}
//		printf("%ld",sum);
//	}
//	return 0;
//}

/*
 完数
 */
//#include <stdio.h>
//#include <stdlib.h>
//#include <time.h>
//int perm(){
//
//	return 0;
//}
//int main(){
//	int N;
//	scanf("%d",&N);
////		if (N<=1000) {
//
//	for (int s=1;s<=(N/2) ; s++) {
//		int input=s;
//		int flag=0;
//		for (int q=1; q<=(input); q++) {
//			int sum=0;
//			for (int i=1; i<=(input); i++)
//			{
//				if (input%i==0 && input!=i)
//				{
//					sum+=i;
//					for (int k=1; k<=(input); k++) {
//						if (input%k==0 && input!=k) {
//							flag=k;
//						}
//					}
//					if(sum==input&&i==flag)
//					{
//						printf("%d its factors are",sum);
//						for (int w=1; w<(input); w++) {
//							if (input%w==0&&w!=input) {
//								printf(" %d",w);
//							}
//						}
//						printf("\n");
//					}
//				}
//			}
//			break;
//		}
//	}
//
////}
//	return 0;
//}
//

/*
 大哥的思路：
 完全数好像真的很少，，6,28,496,8128,33550336，，目测只会考前四个，，，剩下的估计正常算1s之内跑不完程序，，所以无脑直接输出啊hhhhhhh

 */
//#include <stdio.h>
//int main()
//{
//	int n;
//	while (scanf("%d", &n) != EOF) {
//		if (n >= 6)
//            printf("6 its factors are 1 2 3\n");
//        if (n >= 28)
//            printf("28 its factors are 1 2 4 7 14\n");
//        if (n >= 496)
//            printf("496 its factors are 1 2 4 8 16 31 62 124 248\n");
//        if (n >= 8128)
//            printf("8128 its factors are 1 2 4 8 16 32 64 127 254 508 1016 2032 4064\n");
//	}
//	return 0;
//}


/*
 迭代法求平方根
 */
//#include <math.h>
//#include <stdio.h>
//#define NaN = 0.0d / 0.0;
//float InvSqrt(float x)
//{
//	float xhalf = 0.5f*x;
//	int i = *(int*)&x; // get bits for floating VALUE
//	i = 0x5f375a86- (i>>1); // gives initial guess y0
//	x = *(float*)&i; // convert bits BACK to float
//	x = x*(1.5f-xhalf*x*x); // Newton step, repeating increases accuracy
//	return x;
//}
//float SquareRootFloat(float number) {
//	long i;
//	float x, y;
//	const float f = 1.5F;
//
//	x = number * 0.5F;
//	y  = number;
//	i  = * ( long * ) &y;
//	i  = 0x5f3759df - ( i >> 1 );
//	y  = * ( float * ) &i;
//	y  = y * ( f - ( x * y * y ) );
//	y  = y * ( f - ( x * y * y ) );
//	return number * y;
//}
//double newniudun(double a){
//	double x=1.0,x1;
//	do {
//		x1=x;
//		x=(x1+a/x1)/2;
//	} while (fabs(x-x1)>1E-5);
//	return x;
//}
//double SQRT(double x)
//{
//	if(x>100) return 10.0*sqrt(x/100);  //
//    double t = x/8 + 0.5 + 2*x/(4+x); //先迭代两次，把迭代结果做初始值
//    int c = 10;
//    while(c--)
//    {
//        t = (t+x/t)/2;
//    }
//    return t;
//}
//int main()
//{
//	int n;
//	scanf("%d",&n);
//	printf("%0.3lf",SQRT(n));
//	return 0;
//}

/*
 统计字符
 */

//#include <stdio.h>
//int main()
//{
//	int a=0; //字母
//	int b=0;	//数字
//	int c=0;	//空格
//	int d=0;	//其他
//	char arr[999];
//	scanf("%[^\n]",arr);  //读到'\n'结束读取,存入str,再抛弃一个字符
//	/*
//	 int c;
//	 while((c=getchar())!='\n'&&c!=EOF);
//	 //读取一个字符，直到是\n或者是EOF停止
//	 //等价于
//	 scanf("*[^\n]");	 */
//	for (int i=0; arr[i]!='\0'; i++) {
//		if  (arr[i]==32){
//			c++;
//		}else if ((arr[i]>=65 && arr[i]<=90)||(arr[i]>=97&&arr[i]<=122))
//		{
//			a++;
//		}else if (arr[i]>=48 && arr[i]<=57) {
//			b++;
//		}else{
//			d++;
//		}
//	}
//	printf("%d\n%d\n%d\n%d\n",a,c,b,d);
//	return 0;
//}

/*
 阶乘数列
 */

//#include <stdio.h>
//  double  MOD(double a){ //阶乘
//    if (a==0) return 1;
//    return  a*MOD(a-1);
//}
//int main()
//{
//	double sum=0;
//	for (int i=1; i<=30; i++) {
//		sum+=MOD(i);
//	}
//	printf("%.2e\n",sum);
////	printf("2.74e+32\n");
//	return 0;
//}


/*
 最小绝对值
 */

//#include <stdio.h>
//#include <stdlib.h>
//
//void in(int *arr){
//	for (int v=0; v<10; v++) {
//		scanf("%d",&arr[v]);
//	}
//}
//void maxAndMin(int a[],int arr[],int arrb[]){
//
//	int min,max;
//
//	min=a[0];
//	for (int i=0; i<10; i++) {
//		if (a[i]<min) {
//			min=a[i];
//		}
//	}
//
//	max=a[0];
//	for (int k=0; k<10; k++) {
//		if (a[k]>max) {
//			max=a[k];
//		}
//	}
//
////	printf("Max=%d Min=%d \n",max,min);
//
//	//查找出最大值和最小值的位置
//
//	int c=0;
//	while (max!=*a) {
//		a++;
//		c++;
//	}
//
//	int b=0;
//	while (min!=*arr) {
//		arr++;
//		b++;
//	}
//
////	printf("max add=%d min add=%d\n",c,b);
//
//
//	//交换下标
//
//	int tempA,tempB;
//
//
//
//	// max a[9]
//
//
//	tempA=arrb[c];
//
//	arrb[c]=arrb[9];
//
//	arrb[9]=tempA;
//
//
//	// min a[0]
//
//	tempB=arrb[b];
//
//	arrb[b]=arrb[0];
//
//	arrb[0]=tempB;
//
//
////	输出
//
//	for (int j=0; j<10; j++) {
//		printf("%d ",arrb[j]);
//	}
//
////printf("\n");
//
//}
//
//int mainc()
//{
//
//	int d[10];
//
//	in(d);
//
//	int arr[10];
//
//	int arrB[10];
//
//
//	for (int i=0; i<10; i++) {
//		arr[i]=d[i];
//	}
//
//	for (int i=0; i<10; i++) {
//		arrB[i]=d[i];
//	}
//
//	maxAndMin(d,arr,arrB);
//
//
//	return 0;
//}

//#include <stdio.h>
//#include <math.h>
//void into(int *arr){
//	for (int v=0; v<10; v++) {
//		scanf("%d",&arr[v]);
//	}
//}
//void maxAndMin(int a[],int arr[],int arrb[]){
//	int min;
//	min=a[0];  //main是最小值
//	for (int i=0; i<10; i++) {
//		if ( abs(a[i])<min) {
//			min=a[i];
//		}
//	}
//	//查找出最小值的下标
//	int b=0;  		//b就是min的下标
//	while (min!=*arr) {
//		arr++;
//		b++;
//	}
//	//交换下标
//	int tempB;
//	tempB=arrb[b];
//
//	arrb[b]=arrb[9];
//
//	arrb[9]=tempB;
//	//	输出
//
//	for (int j=0; j<10; j++) {
//		printf("%d ",arrb[j]);
//	}
//}
//int main()
//{
//	int d[10];
//
//	into(d);
//	int arr[10];
//
//	int arrB[10];
//
//
//	for (int i=0; i<10; i++) {
//		arr[i]=d[i];
//	}
//
//	for (int i=0; i<10; i++) {
//		arrB[i]=d[i];
//	}
//
//	maxAndMin(d,arr,arrB);
//	return 0;
//}

/*
 自定义函数
 */
//#include <stdio.h>
//double  MOD(double a){ //阶乘
//    if (a==0) return 1;
//    return  a*MOD(a-1);
//}
//double POW(double a, int b)
//{
//    double r = 1.0;
//    double i;
//    for (i = 0; i < b; ++i){
//        r *= a;
//    }
//    return r;
//}
//int main()
//{
//	double x,n;
//	double sum;
//	scanf("%lf%lf",&x,&n);
//	for (int i=1; i<=n; i++) {
//		sum+=POW(-1, i-1)*POW(x, i)/MOD(i);
//	}
//	printf("%.4lf",sum);
//	return 0;
//}

//#include <stdio.h>
//#include <math.h>
//int main()
//{
//	int x;
//	double y;
//	scanf("%d",&x);
//	if (x<0) {
//		y=fabs(x);
//	}else if (x>=0 &&x<2){
//		y=sqrt(x+1);
//
//	}else if (x>=2 && x<4){
//		y=pow(x+2,5);
//	}else{
//		y=2*x+5;
//	}
//	printf("%0.2lf\n",y);
//	return 0;
//}

/*
 温度转换
 */
//#include <stdio.h>
//void cotof(c){
//	for (double i=-100; i<=150; i+=5) {
//		double F=32+i*9/5;
//		printf("c=%.0lf->f=%.0lf\n",i,F);
//
//	}
//}
//int main()
//{
//	double C;
//	cotof(C);
//    return 0;
//}

/*
 寻找矩阵最值
 */
//#include<stdio.h>
//#include <math.h>
//int main()
//{
//    int i, j, row=0, column=0,max=0;
//	int N;
//	scanf("%d",&N);
//	int a[6][6];  /*设置max的初值*/
//	for(i=0;i<N;i++)
//	   {
//		   for(j=0;j<N;j++)
//		   {
//			   scanf("%d",&a[i][j]);
//			   if(fabs(a[i][j])>max)
//			   {
//				   max=fabs(a[i][j]);
//				   row=i;
//				   column=j;
//			   }
//		   }
//	   }
//    printf("%d %d %d",a[row][column],row+1,column+1);
//    return 0;
//}

/*
 BMI=w/h^2
 */
//#include <stdio.h>
//#include <math.h>
//int main()
//{
//	double w;
//	double h;
//	double BMI;
//	printf("请输入你的体重(kg)和身高(m):\n");
//	scanf("%lf %lf",&w,&h);
//	BMI=w/pow(h,2);
//	if (BMI<=18.5) {
//		printf("你太瘦了\n");
//	}else if (BMI>=18.5 && BMI<24.0){
//		printf("你体重正常\n");
//	}else{
//		printf("体重异常\n");
//	}
//
//	return 0;
//}

/*
 成绩归类
 */
//#include <stdio.h>
//int
//int main()
//{
//
//
//	return 0;
//}

//全排列

//#include <stdio.h>
//
//void swap(int arr[],int a,int b){
//    int temp;
//    temp=arr[a];
//    arr[a]=arr[b];
//    arr[b]=temp;
//}
//
//void printfArr(int arr[],int n){
//    for (int i=0; i<n; i++) {
//        printf("%d ",arr[i]);
//    }
//    printf("\n");
//}
//void perm(int arr[],int l,int r){
//    if (l==r) {
//        printfArr(arr, r+1);
//    }else{
//        for (int i=l; i<=r; i++) {
//            swap(arr, l, i);
//            perm(arr, l+1, r);
//            swap(arr, l, i);
//        }
//    }
//}
//
//int main(int argc, const char * argv[]) {
//    // insert code here...
////    printf("Hello, World!\n");
//    int arr[4]={1,2,3,4,};
//    perm(arr, 0,3);
//    return 0;
//}
//



//快排
//#include <stdio.h>
//#include <string.h>
//int Parititionl(int A[],int low,int high){
//	int pivot=A[low];
//	while (low<high) {                        //当左下标小于右下标执行
//		while (low<high && A[high]>=pivot) {  //当
//			--high;
//		}
//		A[low]=A[high];
//		while (low<high&& A[low]<=pivot) {
//			++low;
//		}
//		A[high]=A[low];
//	}
//	A[low]=pivot;
//	return low;
//}
//void QickSort(int A[],int low,int high){
//	if (low<high) {
//		int pivot=Parititionl(A, low, high);
//		QickSort(A, low, pivot-1);
//		QickSort(A, pivot+1, high);
//	}
//}
//int main(){
//	int number;
//	scanf("%d",&number);
//	int arr[number];
//	for (int i=0; i<number; i++) {
//		scanf("%d",&arr[i]);
//	}
//
//	QickSort(arr, 0, number-1);
//	for (int i=0; i<number; i++) {
//		printf("%d ",arr[i]);
//	}
//	return 0;
//}


/*
 二分查找
 */
//#include <stdio.h>
//#include <string.h>
//int binarySearch(int *array,int target,int end){
//	int start=0; //起点 end 终点
//	int mid;  //中间值
//	while (start<=end) { //迭代进行二分查找
//		mid=start+(end-start)/2; //变符号，防止数组溢出
//		if (array[mid]==target) {
//			return mid;
//		}else if (array[mid]<target){
//			start=mid+1;
//		}else{
//			end=mid-1;
//		}
//	}
//	return -1;
//}
//int main(){
//	int arr[10];
//	for (int i=0; i<=9; i++) {
//		arr[i]=i;
//	}
//	printf("%d\n",binarySearch(arr,5,9));
//	return 0;
//}


/*
 1.隔行变色
 w 0
 b 1
 w 2
 b 3
 w 4
 b 5

 b=1 3 5 7 8 9 ~~~~ 奇数 求 21到50的奇数和
 */
//#include <stdio.h>
//int main(){
//	int cnt=0;
//	for (int i=21; i<=50; i++) {
//		if (i%2!=0) {
//			cnt++;
////			printf("%d ",cnt);
//		}
//	}
//	printf("%d",cnt);
//	return 0;
//}

/*
 数字立方的末尾等于该数字本身
 1～1000 内的个数
 for 1~10000 if(swap(i,3)%10==i)
 */

//#include <stdio.h>
//#include <math.h>
//int main(){
//	int cnt=0;
////	printf("%d",(int)(pow(3, 3)));
//	for (int i=1; i<=10000; i++) {
//		if ( ((int)(pow(i, 3))%10) == (i%10) ) {
//			cnt++;
////			printf("i=%d cnt=%d\n",i,cnt);
//		}
//	}
//	printf("%d",cnt);
//	return 0;
//}

///* 0~9
// A B C D
//+E F G B
//---------
//EF C B H
// */
//#include <stdio.h>
//#include <math.h>
//int main(){
//	/*
//	 三=1 低位向高位进一，必定为一
//	 思路: 十进制每位必定是0～9 遍历 且每一位都不相等不为1
//	 */
//
//	int Xiang,Rui,Sheng,Hui,Yang,Xian,Qi;
//	int number1,number2,sum;
//	for (Xiang=0; Xiang<10; Xiang++) {
//		for (Rui=0; Rui<10; Rui++) {
//			for (Sheng=0; Sheng<10; Sheng++) {
//				for (Hui=0; Hui<10; Hui++) {
//						for (Yang=0; Yang<10; Yang++) {
//							for (Xian=0; Xian<10; Xian++) {
//								for (Qi=0; Qi<10; Qi++) {
//									if (Xiang!=Rui && Xiang!=Sheng && Xiang!=Hui && Xiang!=Yang && Xiang!=Xian && Xiang!=Qi
//										&& Rui!=Sheng && Rui!=Hui && Rui!=Yang && Rui!=Xian && Rui!=Qi
//										&& Sheng!=Hui && Sheng!=Yang && Sheng!=Xian && Sheng!=Qi
//										&& Hui!=Yang && Hui!=Xian && Hui!=Qi
//										&& Yang!=Xian && Yang!=Qi
//										&& Xian!=Qi
//										&&Xiang!=1&&Rui!=1&&Sheng!=1&&Hui!=1&&Yang!=1&&Xian!=1&&Qi!=1
//										) {
//										number1=Xiang*1000+Rui*100+Sheng*10+Hui;
//										number2=1*1000+Yang*100+Xian*10+Rui;
//										sum=1*10000+Yang*1000+Sheng*100+Rui*10+Qi;
//										if (sum==(number2+number1)) {
//											printf("1%d%d%d\n",Yang,Xian,Rui);
//										}
//									}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//	return 0;
//}
//

/*

 */

//#include <stdio.h>
//#include <string.h>
//
//void StringInGrid(int width, int height, const char* s)
//{
//	int i,k;
//	char buf[1000];
//	strcpy(buf, s);
//	if(strlen(s)>width-2) buf[width-2]=0;
//
//	printf("+");
//	for(i=0;i<width-2;i++) printf("-");
//	printf("+\n");
//
//	for(k=1; k<(height-1)/2;k++){
//		printf("|");
//		for(i=0;i<width-2;i++) printf(" ");
//		printf("|\n");
//	}
//
//	printf("|");
//
//	printf("%*s",(height+width)/2,s);  //填空
//
//	printf("%*c\n",height,'|');
//
//	for(k=(height-1)/2+1; k<height-1; k++){
//		printf("|");
//		for(i=0;i<width-2;i++) printf(" ");
//		printf("|\n");
//	}
//
//	printf("+");
//	for(i=0;i<width-2;i++) printf("-");
//	printf("+\n");
//}
//
//int main()
//{
//	StringInGrid(20,6,"abcd1234");
////	printf("%*d\n",5,1); // out:    1(前面4个空格) 超出不会截取
////	printf("%.*s", 3, "abcdef");//out:abc 截取前三位
//	return 0;
//}

/*
 串逐位和

 给定一个由数字组成的字符串，我们希望得到它的各个数位的和。
 比如：“368” 的诸位和是：17
 这本来很容易，但为了充分发挥计算机多核的优势，小明设计了如下的方案：
 */

//#include <stdio.h>
//#include <string.h>
//int f(char s[], int begin, int end)
//{
////	int mid;
////	if(end-begin==1) return s[begin] - '0';
////	mid = (end+begin) / 2;
//////	return ____________________________________;  //填空
//	int sum = 0;
//	for (int i=begin; i<end; i++) {
//		sum+=s[i]-'0'; //s[i]-'0' 字符串转数字
//	}
//	return sum;
//}
//
//int main()
//{
//	char s[] = "4725873285783245723";
//	printf("%d\n",f(s,0,strlen(s)));
//
//	return 0;
//}


/*
 打印X 输入m n
 */
//#include <stdio.h>
//int main()
//{
//    int m,n;
//    scanf("%d %d",&m,&n);
//    if ( (m>0) && (m<n) && (n>3) && (n<1000) && (n%2!=0) ) {  // 0<m<n && 3<n<1000 && n%2!=0
//        int x,y;
//        for (x=0; x<n; x++) {
//            for (y=0; y<(m+n-1); y++) {
//                if ( ((y>=x)&&(y<m+x)) || ((y<n-x+m-1)&&(y>n-x-2))  ) {  //别问，问就是试出来的
//                    printf("*");
//                }else{
//                    printf(".");
//                }
//            }
//            printf("\n");
//        }
//    }
//
//    return 0;
//}

/*

 奇妙的数字

 小明发现了一个奇妙的数字。它的平方和立方正好把0~9的10个数字每个用且只用了一次。
 你能猜出这个数字是多少吗？
 pow(number,2|3)=1234567890

 看到这题目想到的就是 for 循环遍历数字，然后计算它的平方和立方再去判断它们刚好使用0-9这10个数各一次。

 */
/*
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 int weishu(long long n){
 int cnt=0;
 while (n!=0) {
 n/=10;
 ++cnt;
 }
 return cnt;
 }
 int main(){
 //	看到这题目想到的就是 for 循环遍历数字，然后计算它的平方和立方再去判断它们刚好使用0-9这10个数各一次。
 for (int i=0; i<100; i++) {
 long long pf=i*i;
 long long cf=i*i*i;
 if (weishu(pf)+weishu(cf)==10) { //1.两个数相加是10位数
 //			printf("%lld %lld\n",pf,cf);
 char Spf[5]; //0~3
 char Scf[7]; //0~5
 sprintf(Spf, "%lld",pf); //复制 pf 到Spf 字符串
 sprintf(Scf, "%lld",cf);
 if (Spf[0]!=Spf[1] && Spf[0]!=Spf[2] && Spf[0]!=Spf[3] && Spf[0]!=Spf[3] && Spf[0]!=Scf[0] && Spf[0]!=Scf[1] && Spf[0]!=Scf[2] && Spf[0]!=Scf[3] && Spf[0]!=Scf[4] && Spf[0]!=Scf[5] &&

 Spf[1]!=Spf[2] && Spf[1]!=Spf[3] && Spf[1]!=Spf[3] && Spf[1]!=Scf[0] && Spf[1]!=Scf[1] && Spf[1]!=Scf[2] && Spf[1]!=Scf[3] && Spf[1]!=Scf[4] && Spf[1]!=Scf[5] &&

 Spf[2]!=Spf[3] && Spf[2]!=Scf[0] && Spf[2]!=Scf[1] && Spf[2]!=Scf[2] && Spf[2]!=Scf[3] && Spf[2]!=Scf[4] && Spf[2]!=Scf[5] &&
 Spf[3]!=Scf[0] && Spf[3]!=Scf[1] && Spf[3]!=Scf[2] && Spf[3]!=Scf[3] && Spf[3]!=Scf[4] && Spf[3]!=Scf[5] //2.每一位都不相等
 ) {
 printf("二次方:%s 三次方:%s 原数:%d\n",Spf,Scf,i);

 }


 }


 }
 return 0;
 }
 */

//#include <stdio.h>
//int judge(int a,int b){
//	int A[10]={0};
//	int B[10]={0};
//	while (a>0)
//		A[a%10]++,a/=10;
//	while (b>0)
//		B[b%10]++,b/=10;
//	return 0;
//}
//int weishu(long long n){
//	int cnt=0;
//	while (n!=0) {
//		n/=10;
//		++cnt;
//	}
//	return cnt;
//}
//int main(){
//	for (int i=0; i<=100; i++) {
//		if (weishu(i*i)+weishu(i*i*i)==10) {
//			printf("%d\n",i);
//		}
//	}
//	return 0;
//}

/*
 1、小明带两个妹妹参加元宵灯会。别人问她们多大了，她们调皮地说：“我们俩的年龄之积是年龄之和的6倍”。小明又补充说：“她们可不是双胞胎，年龄差肯定也不超过8岁啊。”请你写出：小明的较小的妹妹的年龄。
 */
//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    for (int i=1; i<=100; i++) {
//        for (int j=1; j<=100; j++) {
//            if (((i+j)*6==(i*j))&&(i!=j)&&(j-i<=8)&&(i-j<=8)) {
//				printf("%d %d\n",i,j);
//			}
//        }
//    }
//    return 0;
//}

/*
 a b c d e  ab*cde=adb*ce
 */
//#include <stdio.h>
//int main()
//{
//	int a,b,c,d,e;
//	int cnt=0;
//	for (a=1; a<10; a++) {
//		for (b=1; b<10; b++) {
//			for (c=1; c<10; c++) {
//				for (d=1; d<10;d++) {
//					for (e=1; e<10; e++) {
//						if ((a*10+b)*(c*100+d*10+e)==((a*100+d*10+b)*(c*10+e))&&(a!=b&&a!=c&&a!=d&&a!=e&&b!=c&&b!=d&&b!=e&&c!=d&&c!=e&&d!=e)) {
//							printf("%d%d*%d%d%d=%d%d%d*%d%d\n",a,b,c,d,e,a,d,b,c,e);
//							cnt++;
//						}
//					}
//				}
//			}
//		}
//	}
//	printf("%d\n",cnt);
//	return 0;
//}

/*
 7.比较字符串

 */

//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	char arrOne[100];
//	char arrTwo[100];
//	scanf("%s",arrOne);
//	scanf("%s",arrTwo);
//	printf("%d\n",strcmp(arrOne, arrTwo));
//	return 0;
//}

/*
 7.AN
 A1 = “A”
 　　A2 = “ABA”
 　　A3 = “ABACABA”
 　　A4 = “ABACABADABACABA”
 */

//#include <stdio.h>
//#include <string.h>
//int main()
//{
//	int a;
//	scanf("%d",&a);
//	switch (a) {
//		case 1:
//			printf("");
//			break;
//		case 2:
//			printf("");
//			break;
//		case 3:
//			printf("");
//			break;
//		case 4:
//			printf("");
//			break;
//		case 5:
//			printf("");
//			break;
//		case 6:
//			printf("");
//			break;
//		case 7:
//			printf("");
//			break;
//		case 8:
//			printf("");
//			break;
//		case 9:
//			printf("");
//			break;
//		case 10:
//			printf("");
//			break;
//
//		case 11:
//			printf("");
//			break;
//
//
//		case 12:
//			printf("");
//			break;
//
//		case 13:
//			printf("");
//			break;
//
//		case 14:
//			printf("");
//			break;
//
//		case 15:
//			printf("");
//			break;
//
//		case 16:
//			printf("");
//			break;
//
//		case 17:
//			printf("");
//			break;
//		case 18:
//			printf("A");
//			break;
//
//
//		case 19:
//			printf("A");
//			break;
//
//
//		case 20:
//			printf("A");
//			break;
//
//
//		case 21:
//			printf("A");
//			break;
//
//		case 22:
//			printf("A");
//			break;
//		case 23:
//			printf("A");
//			break;
//		case 24:
//			printf("A");
//			break;
//
//		default:
//			break;
//	}
//	return 0;
//}

/*
 X国是个小国。国王K有6个儿子。在临终前，K国王立下遗嘱：国王的一批牛作为遗产要分给他的6个儿子。其中，大儿子分1/4，二儿子1/5，三儿子1/6，....直到小儿子分1/9。牛是活的，不能把一头牛切开分。最后还剩下11头牛，分给管家。请计算国王这批遗产中一共有多少头牛
 */
//#include <stdio.h>
//int main(){
//
//	//1.for
//	int OX;
//	for (OX=22; OX<=2520; OX++) if (OX%4==0 && OX%5==0 && OX%6==0 && OX%7==0 && OX%8==0 && OX%9==0 &&OX/1000!=5 && OX/1000!=7) printf("%d\n",OX);
//
//	//2.while
//	double x=1.0;
//	while (x!= (1.0/4.0*x + 1.0/5.0*x + 1.0/6.0*x +1.0/7.0*x + 1.0/8.0*x + 1.0/9.0*x + 11) ) x++;
//	printf("%0.0lf\n",x);
//	return 0;
//}

/*
 对1,2,3,4,5,6六个数字进行全排列，有两个条件：1.第三个数不能是4； 2.数字3和5不能相邻；
 */

//#include <stdio.h>
//
//int main(){
//	int arr[6]={1,2,3,4,5,6};
//
//	return 0;
//}

/*
 输入两个整数，输入他们乘积百位上的数
 e.g. 59 147 = 8763 =  6
 */
//#include <stdio.h>
////#include<conio.h>
//
//int main()
//{
//	int a,b,c;
//	/**/int f;/**/
//	printf("Please input a,b :");
//	scanf("%d,%d",&a,&b);
//	f=a*b;
//	c=/**/f/100%10/**/;
//	printf("%d\n",/**/c/**/);
//	return 0;
//}

/*
 6.改错
 */

/*
 约瑟夫环
 */


//#include <stdio.h>
//int josephusProblem(int n,int m){  // n is input, m is kill number
////	return n==1?n:(josephusProblem(n-1,m)+m-1)%n+1;
//	if (n==1) {
//		return n;
//	}else{
//		return (josephusProblem(n-1,m)+m-1)%n+1;
//	}
//}
//int main()
//{
//	int n;
//	scanf("%d",&n);
//	printf("%d",josephusProblem(n, 3));
//    return 0;
//}

//#include<stdio.h>
//#include <string.h>
//#define N 1000000 //记录玩游戏最大人数
//int flag [N] = {0};
//int main()
//{
//    int n = 0, m = 3;
//    scanf("%d", &n);//输入玩游戏人数和计数m
//    int i = 0;
//    int count = 0;  //记录已经出圈的人数
//    int num = 0;    //报数器
//    for(i = 1; i <= n; i++) {
//        flag [i] = 1;//所有人入圈
//    }
//    while(count < n - 1) {
//        for(i = 1; i <= n; i++ ) {
//            if (1 == flag[i]) {//在未出圈的人数中计数
//                num++;
//                if(num == m) {//此人数到m则出圈
//                    printf("%d\n", i);
//                    count++;//出圈人数加1
//                    flag [i] = 0;//出圈
//                    num = 0;
//                }
//                if(count == n - 1) {
//                    break;
//                }
//            }
//        }
//    }
//    for(i = 1; i <= n; i++) {
//        if(1 == flag[i]) {//输出赢家，标识为1
//            printf("The last one is : %d\n", i);
//        }
//    }
//
//    return 0;
//}

/*
 猜年龄
 */
//#include <stdio.h>
//#include <math.h>
//int judge(int a,int b)
//{
//
//	int A[10]= {0};
//	int B[10]= {0};
//
//	int i;
//
//	while(a>0){
//		A[a%10]++;
//		a/=10;
//	}
//	while(b>0){
//		B[b%10]++;
//		b/=10;
//
//	}
//	for(i=0; i<10; i++)
//	{
//		if(A[i]+B[i]>=1 && A[i]+B[i]<2 )
//			return 0;
//	}
//	return 1;
//}
//int main(){
//	for (int i=17; i<20; i++) {
//		int three=i*i*i; // 1234
//		int five=i*i*i*i;   // 123456
//		judge(three,five);
//		if (judge(three, five)==0 && three/1000!=0 && five/100000!=0 ) {
//			printf("年龄:%d\n",i);
//			printf("%d %d\n",three,five);
//			break;
//		}
//	}
//	return 0;
//}

/*
 马虎的算式

 */
//#include <stdio.h>
//#include <math.h>
//
//int main(){
//
//	int cnt=0;
//	for(int a=1;a<10;a++)
//		for(int b=1;b<10;b++)
//			for(int c=1;c<10;c++)
//				for(int d=1;d<10;d++)
//					for(int e=1;e<10;e++)
//						if( ((a*10+b)*(c*100+d*10+e)==(a*100+d*10+b)*(c*10+e)) && a!=b&&a!=c&&a!=d&&a!=e&& b!=c&&b!=d&&b!=e && c!=d&&c!=e )
//							cnt++;
//	printf("%d\n",cnt);
//	return 0;
//}
//


/*
 中华
 */

//递归法

//#include <stdio.h>
//#include <string.h>
//int fun(int x,int y){
//	if (x==1|| y==1) {
//		return 1;
//	}
//	return fun(x-1, y)+fun(x, y-1);
//}
//
//int main()
//{
//	printf("%d\n",fun(5, 4));
//	return 0;
//}

//#include <stdio.h>
//#include <string.h>
//int fun(int x,int y){
//	if (x==1|| y==1) {
//		return 1;
//	}
//	return fun(x-1, y)+fun(x, y-1);
//}
//int main()
//{
//	printf("%d\n",fun(5, 4));
//	return 0;
//}

//穷举法
//#include<stdio.h>
//int main()
//{
//	int a,b,c,d,e,f,g;
//	int x=0,y=0;
//	for(a=0;a<2;a++)
//	{
//		for(b=0;b<2;b++)
//		{
//			for(c=0;c<2;c++)
//			{
//				for(d=0;d<2;d++)
//				{
//					for(e=0;e<2;e++)
//					{
//						for(f=0;f<2;f++)
//						{
//							for(g=0;g<2;g++)
//							{
//									x=a+b+c+d+e+f+g;
//									if(x==4)
//									{
//										y++;
//										printf("%d %d %d %d %d %d %d\n",a,b,c,d,e,f,g);
//									}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//	printf("%d\n",y);
//}


/*
 幻方
 4阶
 a~p
 */

//#include<stdio.h>
//int hangfang()
//{
//	int cnt=0;
//	int a=16;
//	int d=13;
//	int g=11;
//	int i=9;
//	int n=15;
//	int p=1;
//	for (int b=1; b<=16; b++) {
//		for (int c=1; c<=16; c++) {
//			for (int e=1; e<=16; e++) {
//				for (int f=1; f<=16; f++) {
//					for (int h=1; h<=16; h++) {
//						for (int j=1; j<=16; j++) {
//							for (int k=1; k<=16; k++) {
//								for (int l=1; l<=16; l++) {
//									for (int m=1; m<=16; m++) {
//										for (int o=1; o<=16; o++) {
//											cnt++;
//											if (((a+b+c+d)==34)&&((e+f+g+h)==34)&&((i+j+k+l)==34)&&((m+n+o+p)==34)&&(a+e+i+m==34)&&((b+f+j+n)==34)&&((c+g+k+o)==34)&&((d+h+l+p)==34)&&((a+f+k+p)==34)&&((m+j+g+d)==34)) {
//												printf("%2d %d %d %d\n%d %d %d %d\n%d %d %d %d\n%d %d %d %d\n",a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
//											}
//										}
//									}
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//	printf("cnt:%d\n",cnt);
//	return 0;
//}


/*
 16 1 4 13
 5 12 11 6
 9 6 5 14
 4 15 14 1

 16 2 3 13
 5 11 11 7
 9 6 6 13
 4 15 14 1

 16 3 2 13
 5 10 11 8
 9 6 7 12
 4 15 14 1

 16 4 1 13
 5 9 11 9
 9 6 8 11
 4 15 14 1
 */

/*
 数据结构
 1.线性存储
 2.顺序存储
 3.链式存储
 */
//#include <stdio.h>
//#include <stdlib.h>
//
//
//typedef struct sequenList{
//	int a[20];
//	int len;
//}SEQ;
//
//void init(SEQ * sep){
//	sep->a[0]=0;
//	sep->len=0;
//}
//
//void insrt(SEQ *seq,int x,int i){
//
//	if (seq->len>=19) {
//		printf("Not");
//	}else if (i<1||i>seq->len+1){
//		printf("Not");
//	}else{
//		for (int j=seq->len; j>=i; j--) {
//			seq->a[j+1]=seq->a[j];
//		}
//		seq->a[i]=x;
//		seq->len++;
//	}
//
//}
//void dele(SEQ *seq,int i){
//	if (i<1||i>seq->len) {
//		printf("No");
//	}else{
//		for (int j=i+1; j<=seq->len; j++) {
//			seq->a[j]=seq->a[j+1];
//		}
//		seq->len--;
//	}
//}
//int locate(SEQ* seq,int x){
//	for (int i=1; i<=seq->len; i++)
//	if(seq->a[i]==x) return i;
//	return -1;
//}
////int prior(int x,SBQ* seq){
////
////	return 1;
////}
//
//
//int main(){
//	SEQ* p=(SEQ*)malloc(sizeof(SEQ));
//
//	return 0;
//}


/*
 实现链表

 a1->a2->a3->a4

 One:value Two: address
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct like{
    int data;
    struct like* next; //指向结构体的指针
}LK; //别名为 LK

//头插法
LK* headcreate(int n){
    LK* head;
    head=malloc(sizeof(LK));
    head->data=10;
    head->next=NULL;
    int i;
    for (i=1; i<=n; i++) {
        LK* s;
        s=malloc(sizeof(LK));
        printf("Please input %d is value",i);
        scanf("%d",&s->data);
        s->next=head->next;
        head->next=s;
    }
    return head;
}
void myPrint(LK* head){
    LK* p=head->next;
    while (p!=NULL) {
        printf("->%d",p->data);
        p=p->next;
    }
}

//定位
LK* locate(LK* head,int x){
    LK* p=head->next;
    while (p!=NULL) {
        if (p->data==x) {
            return p;
        }
        p=p->next;
    }
    return NULL;
}
//插入，在链表值为y的节点后插入x节点
void insert(LK* head,int x,int y){
    LK* q=locate(head, y);
    if (NULL==q) {
        printf("Not find is %d",y);
    }else{
        LK* p=malloc(sizeof(LK));
        p->data=x;
//        p->next=;
    }

}
int main()
{

    return 0;
}
