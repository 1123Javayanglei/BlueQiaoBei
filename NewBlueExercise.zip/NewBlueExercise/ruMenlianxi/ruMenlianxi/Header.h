//
//  Header.h
//  ruMenlianxi
//
//  Created by 杨磊 on 2019/11/3.
//  Copyright © 2019 Yang. All rights reserved.
//

#ifndef Header_h
#define Header_h
#define INT(a) printf("%d\n",a)


#endif /* Header_h */
